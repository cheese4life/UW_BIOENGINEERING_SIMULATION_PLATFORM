# How to sign the driver for Secure Boot

To be able to use the socketCAN driver in a secure environment (UEFI Secure boot),
the driver has to be signed so that is can be validated against a known key at boot.

For more information to Secure Boot, see:

- [Ubuntu Blog](https://ubuntu.com/blog/how-to-sign-things-for-secure-boot)
- [Debian SecureBoot](https://wiki.debian.org/SecureBoot)
- [Ubuntu Wiki](https://wiki.ubuntu.com/UEFI/SecureBoot)


Please follow the following steps: 

1. Generate the key
2. Register the key
3. Sign the driver
4. Install the driver

If you already have private and public keys  go to step 2.
If you already have both keys and the public key is already registered on your system go to step 3.


## 1. Generate the key

For that you have to create two Machine Owner Keys (MOK for short),
a private one to sign the driver and a public one for the boot firmware.

Before you can generate the MOK (machine owner key) files:

### 1.1 Check if openssl is installed

​	open a terminal and enter 'openssl version'

### 1.2 adapt the file km.ssl.conf` with your details:

**Abstract from "km.ssl.conf"*

```
[ req ]
distinguished_name      = req_distinguished_name
x509_extensions         = v3
string_mask             = utf8only
prompt                  = no

[ req_distinguished_name ]
countryName             = CA
stateOrProvinceName     = Quebec
localityName            = Montreal
0.organizationName      = cyphermox
commonName              = Secure Boot Signing
emailAddress            = example@example.com
```

Rename and adapt the file according to your organization, update `req_distinguished_name`
under `[ req ]`, and the field and values under `[ req_distinguished_name ]`.


To generate the MOK files, call the script `./ssl_generateKey.sh`. As result you get two files:

- `KM_MOK.priv` as private key, and
- `KM_MOK.der` as public key


## 2. Register the key

To register the MOK files, call the script `./ssl_registerKey.sh`

This script directly adds the public key `HMS_MOK.der` file to the MOK list. <password?>

After that you have to reboot your PC and enter the password again.
This step is normally only necessary once for each computer you want to install the driver.


## 3. Sign the driver

To sign a kernel mode driver ( for example a socketCAN driver), copy the file `HMS_MOK.priv`and `HMS_MOK.der` into the current project folder
and call the script `./ssl_signDriver.sh *.ko` (`*.ko` is the name of the driver).
This is necessary each time you change and recompile the driver.


## 4. Install the driver

To install the signed driver, call `sudo make install` on the root path of you kernel mode driver package.


## History

**2021-02-16 v0.3**
- update of the readme.md
- update of the ssl_generateKey.sh script
  solves a problems with the generated ".rnd" file

**2020-12-10 v0.2**
- History added

**2020-12-08 v0.1**
- First draft


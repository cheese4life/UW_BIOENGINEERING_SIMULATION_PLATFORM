#!/bin/bash

MOK_PRIV="KM_MOK.priv"
MOK_DER="KM_MOK.der"
  
#
# Certificates in shim
#
if [ -f $MOK_DER ] || [ -f $MOK_PRIV ]; then
    read -p "certificate already exists. Do you want to delete? [y/n] " delete
    ## Only delete the file if y or Y is pressed. Any other key would cancel it. It's safer this way.
    if [[ $delete == [yY] ]]; then
      rm $MOK_DER
      rm $MOK_PRIV
      echo "File deleted."  ## Only echo "File deleted." if it was actually deleted and no error has happened. rm probably would send its own error info if it fails.
    else
      echo "leaving script without creating a new certificate"
    fi
fi

if [ ! -f $MOK_DER ] && [ ! -f $MOK_PRIV ]; then
  echo "create File $MOK_DER, $MOK_PRIV"
  if [ ! -f ~/.rnd ]; then
    openssl rand -out ~/.rnd -writerand ~/.rnd -hex 256
  fi

  openssl req -config ./km.ssl.conf -new -x509 -newkey rsa:2048 -nodes -days 36500 -outform DER -keyout $MOK_PRIV -out $MOK_DER
fi

  


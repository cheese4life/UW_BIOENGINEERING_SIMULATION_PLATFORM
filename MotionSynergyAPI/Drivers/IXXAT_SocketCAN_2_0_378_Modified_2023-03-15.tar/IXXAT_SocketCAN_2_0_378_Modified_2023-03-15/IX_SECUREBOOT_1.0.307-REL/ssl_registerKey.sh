#!/bin/bash
MOK_DER="KM_MOK.der"
  
#
# Certificates in shim
#
if [ -f $MOK_DER ]; then
  echo "enroll the Key $MOK_DER"
    
  #
  # enrolling the key
  #            
  sudo mokutil --import $MOK_DER
  
  echo "Now reboot the computer to enroll the new certificate !"
fi
  


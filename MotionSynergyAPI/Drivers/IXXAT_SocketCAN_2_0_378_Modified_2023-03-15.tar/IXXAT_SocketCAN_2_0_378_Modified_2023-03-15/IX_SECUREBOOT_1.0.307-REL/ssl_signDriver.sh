#!/bin/bash

if [ -z "$1" ]; then
  echo " Module name is missing !!"
else  

  KMOD_NAME="$1"
  MOK_PRIV="~/KM_MOK.priv"
  MOK_DER="~/KM_MOK.der"  
  
  #
  # Certificates in shim
  #
  if [ ! -f $MOK_DER ]; then
    echo "please call the script to create a new certificate"
  else
    #
    # Let us sign things
    #
    kmodsign sha512 $MOK_PRIV $MOK_DER $KMOD_NAME

    #
    # verify
    #
    hexdump -Cv $KMOD_NAME | tail -n 5
  fi
fi


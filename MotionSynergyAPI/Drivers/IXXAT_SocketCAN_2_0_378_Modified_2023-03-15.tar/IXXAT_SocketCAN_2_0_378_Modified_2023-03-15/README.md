# Ixxat SocketCAN Drivers

This archive contains four different archives with board specific HMS Ixxat socketCAN drivers:

- `ix_active_can_2.0.xxx-REL.tgz` for all IB2xx, IB4xx, IB6xx, and IB810 boards
- `ix_passive_can_2.0.xxx-REL.tgz`  for all IB100, IB120, IB130, and IB300 boards
- `ix_passive_canfd_2.0.xxx-REL.tgz` for all IB500 and IB520 boards
- `ix_usb_can_2.0.xxx-REL.tgz` for all USB-to-CAN V2 and USB-to-CAN-FD family adapters

Please unpack and install the appropriate driver.


The archive `IX_SECUREBOOT_1.0.xxx-REL.tgz` contains the scripts to sign the driver for Secure Boot. 
This is necessary in order to be able to use the socketCAN driver in a secure environment (UEFI Secure boot).

The archive `IX_SocketCAN-example_1.0.xxx-REL.tgz` contains the some information and C examples for the first steps with socketCAN. 

------------------------------------------
2022-02-11 Modified by Peter Wucherer
           Add flags to compile it on Kernel 5.10 and newer
2022-04-08 Change in USB driver that USB-to-CAN V2 with
           firmware version below V1.7 could receive data
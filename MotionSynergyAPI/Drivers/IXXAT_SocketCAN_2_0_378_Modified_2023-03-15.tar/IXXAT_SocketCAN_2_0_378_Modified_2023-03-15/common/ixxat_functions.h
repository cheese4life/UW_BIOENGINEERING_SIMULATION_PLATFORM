#ifndef __IXXAT_FUCTIONS_H__
#define __IXXAT_FUCTIONS_H__

#include <linux/version.h>
#include <linux/can/dev.h>

#if KERNEL_VERSION(5, 11, 0) >= LINUX_VERSION_CODE
  #define can_fd_dlc2len(dlc) can_dlc2len(get_canfd_dlc(dlc))
  #define can_fd_len2dlc(dlc) can_len2dlc(dlc)

  #define can_cc_dlc2len(dlc) get_can_dlc(dlc)
#endif

#if defined(CONFIG_TRACING) && defined(DEBUG)
	#define ix_trace_printk(...) trace_printk(__VA_ARGS__)
#else
	#define ix_trace_printk(...)
#endif

// since Kernel 5.19.0 there are some functions
// removed, original in the include file led.h
// define here empty functions
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 19, 0)
#define CAN_LED_EVENT_OPEN 0
#define CAN_LED_EVENT_STOP 1
#define CAN_LED_EVENT_TX   2
#define CAN_LED_EVENT_RX   3
#define can_led_event(netdev,event)
#define devm_can_led_init(netdev)
#define can_led_notifier_init()
#define can_led_notifier_exit()
#endif




#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 13, 0)
static inline void ixx_can_free_echo_skb(struct net_device *dev, unsigned int idx)
{
  can_free_echo_skb(dev, idx);
}

static inline unsigned int ixx_can_get_echo_skb(struct net_device *dev, unsigned int idx)
{
  return can_get_echo_skb(dev, idx);
}
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 10, 0)
static inline void ixx_can_put_echo_skb(struct sk_buff *skb, struct net_device *dev, unsigned int idx)
{
  can_put_echo_skb(skb, dev, idx);
}
#else
static inline int ixx_can_put_echo_skb(struct sk_buff *skb, struct net_device *dev, unsigned int idx)
{
 return can_put_echo_skb(skb, dev, idx);
}
#endif
#else
static inline void ixx_can_free_echo_skb(struct net_device *dev, unsigned int idx)
{
  can_free_echo_skb(dev, idx, NULL);
}

static inline unsigned int ixx_can_get_echo_skb(struct net_device *dev, unsigned int idx)
{
  return can_get_echo_skb(dev, idx, NULL);
}

static inline int ixx_can_put_echo_skb(struct sk_buff *skb, struct net_device *dev, unsigned int idx)
{
 return can_put_echo_skb(skb, dev, idx, 0);
}
#endif

#endif
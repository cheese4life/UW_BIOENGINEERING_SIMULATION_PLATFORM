#ifndef __IXXAT_FUCTIONS_PCI_H__
#define __IXXAT_FUCTIONS_PCI_H__

#include <linux/version.h>
#include <linux/can/dev.h>


// removed with Kernel 5.18.0
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 18, 0)
static inline void *
pci_alloc_consistent(struct pci_dev *hwdev, size_t size,
		     dma_addr_t *dma_handle)
{
	return dma_alloc_coherent(&hwdev->dev, size, dma_handle, GFP_ATOMIC);
}

static inline void
pci_free_consistent(struct pci_dev *hwdev, size_t size,
		    void *vaddr, dma_addr_t dma_handle)
{
	dma_free_coherent(&hwdev->dev, size, vaddr, dma_handle);
}
#endif


#endif
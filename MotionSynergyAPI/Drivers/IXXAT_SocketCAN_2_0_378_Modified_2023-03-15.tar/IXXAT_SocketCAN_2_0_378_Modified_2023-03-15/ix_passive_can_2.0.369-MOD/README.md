# IXXAT PASSIVE IFI CAN PCI Cards Driver

The IXXAT PASSIVE IFI CAN PCI cards linux driver provides support for the following devices:

* IXXAT CAN-IB100/PCIe      
* IXXAT CAN-IB120/PCIe mini 
* IXXAT CAN-IB130/PCIe 104
* IXXAT CAN-IB300/PCI

## Install

The installation of the linux driver requires that the linux kernel header files
and the necessary build tools are installed on your system. You can install them as follows:

Debian based systems:

```
$ sudo apt install linux-headers-$(uname -r)
$ sudo apt install --reinstall build-essential
```

Fedora and Red Hat:

```
$ su -
# yum -y install kernel-devel kernel-headers
# yum -y groupinstall 'Development Tools'
```

You can check if the headers are installed by running the following command:

```
$ ls /usr/src/linux-headers-$(uname -r)
```

Compile the kernel module by running make:

```
$ make all
```

You can then install the module by running:

Debian based systems:

```
$ sudo make install
```

Fedora and Red Hat:

```
$ su -
# make install
```

This will build your modules, install them in a shared directory and load
them into the kernel.

Congratulations! You can now use the IXXAT PASSIVE IFI CAN PCI cards.

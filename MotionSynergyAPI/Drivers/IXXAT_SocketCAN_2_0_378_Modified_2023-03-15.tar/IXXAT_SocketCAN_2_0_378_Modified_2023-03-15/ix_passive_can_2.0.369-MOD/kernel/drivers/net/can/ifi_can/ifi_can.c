// SPDX-License-Identifier: GPL-2.0

/* CAN driver base for IXXAT PCI-to-CAN
 *
 * Copyright (C) 2018 HMS Industrial Networks <socketcan@hms-networks.de>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published
 * by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 */
#include <linux/clk.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/can/dev.h>
#include <linux/version.h>

#include "ifi_can.h"

#define IFI_CAN_TSEG1_MIN 1
#define IFI_CAN_TSEG1_MAX 32
#define IFI_CAN_TSEG2_MIN 2
#define IFI_CAN_TSEG2_MAX 33
#define IFI_CAN_SJW_MAX 4
#define IFI_CAN_BRP_MIN 2
#define IFI_CAN_BRP_MAX 257
#define IFI_CAN_BRP_INC 1

#define IXXAT_PCI_TIMEOUT 1000

#define IXXAT_TIMER     50 // ms

#define  IXXAT_IF_RX_RD_MASK  (IFI_CAN_STATUS_RD_I_RNE   | \
								IFI_CAN_STATUS_RD_I_RBF  | \
								IFI_CAN_STATUS_RD_I_RBO  | \
								IFI_CAN_STATUS_RD_I_BOFF | \
								IFI_CAN_STATUS_RD_I_WARN | \
								IFI_CAN_STATUS_RD_I_ERR )

#define  IXXAT_IF_TX_RD_MASK  (IFI_CAN_STATUS_RD_I_TBE | \
								IFI_CAN_STATUS_RD_I_TOK)

#define  IXXAT_IF_TX_WR_ENA   (IFI_CAN_INTMASK_WR_TBE | \
								IFI_CAN_INTMASK_WR_TOK | \
								IFI_CAN_INTMASK_WR_RNE | \
								IFI_CAN_INTMASK_WR_BO  | \
								IFI_CAN_INTMASK_WR_RBO | \
								IFI_CAN_INTMASK_WR_RBF | \
								IFI_CAN_INTMASK_WR_EI  | \
								IFI_CAN_INTMASK_WR_EW )


MODULE_AUTHOR("HMS Technology Center Ravensburg Gmbh <socketcan@hms-networks.de>");
MODULE_DESCRIPTION("driver for IFI CAN controller");
MODULE_LICENSE("GPL v2");
MODULE_VERSION("1.0");

#if KERNEL_VERSION(5, 10, 17) > LINUX_VERSION_CODE
  #define can_cc_dlc2len(dlc) get_can_dlc(dlc)
#endif

//#define DEBUG 1
//#define CONFIG_TRACING 1

#if defined(CONFIG_TRACING) && defined(DEBUG)
	#define ix_trace_printk(...) trace_printk(__VA_ARGS__)
#else
	#define ix_trace_printk(...)
#endif

static const struct can_bittiming_const ifi_can_bittiming_const = {
	.name = KBUILD_MODNAME, // IXXAT_PCI_DEV_NAME,
	.tseg1_min	= IFI_CAN_TSEG1_MIN,
	.tseg1_max	= IFI_CAN_TSEG1_MAX,
	.tseg2_min	= IFI_CAN_TSEG2_MIN,
	.tseg2_max	= IFI_CAN_TSEG2_MAX,
	.sjw_max	= IFI_CAN_SJW_MAX,
	.brp_min	= IFI_CAN_BRP_MIN,
	.brp_max	= IFI_CAN_BRP_MAX,
	.brp_inc	= IFI_CAN_BRP_INC,
};


static u32 ifi_can_msg_get_next_idx(struct net_device *netdev)
{
	struct ifi_can_priv *priv = netdev_priv(netdev);

	u32 MsgIdx  = 0;
	u32 LoopCnt = 0;
	u64 Mask;

	MsgIdx = (priv->msg_index + 1) % priv->can.echo_skb_max;
	while (LoopCnt < priv->can.echo_skb_max) {
		Mask = (1 << MsgIdx);

		if ((priv->msgs & Mask) == 0) {
			priv->msgs |= Mask;
			break;
		}

		MsgIdx = (MsgIdx + 1) % priv->can.echo_skb_max;
		LoopCnt++;
	}

	if (LoopCnt < priv->can.echo_skb_max) {
		priv->msg_index = MsgIdx;
		
		return MsgIdx;
	} else
		return IFI_CAN_E_FAILED;
}

static void ifi_can_msg_free_idx(struct net_device *netdev, u32 MsgIdx)
{
	struct ifi_can_priv *priv = netdev_priv(netdev);
	u64 Mask;
	
	if (MsgIdx == 0xFFFFFFFF) {
		priv->msgs = 0;
		priv->msg_index = 0;
	} else {
		if  (MsgIdx < priv->can.echo_skb_max) {
			Mask = (1 << MsgIdx);
			priv->msgs &= ~Mask;
		}
	}
}

static int ifi_can_get_berr_counter(const struct net_device *ndev,
				    struct can_berr_counter *bec)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	u32 err = ioread32(priv->base + IFI_CAN_ERROR);

	bec->rxerr = (err >> IFI_CAN_ERROR_RX_OFFSET) &
		     IFI_CAN_ERROR_RX_MASK;
	bec->txerr = (err >> IFI_CAN_ERROR_TX_OFFSET) &
		     IFI_CAN_ERROR_TX_MASK;

	return 0;
}

static int ifi_can_handle_lost_msg(struct net_device *ndev)
{
	struct net_device_stats *stats = &ndev->stats;
	struct can_frame *frame;
	int work_done = 0;
	struct sk_buff *skb = NULL;

	ifi_can_msg_free_idx(ndev, 0xFFFFFFFF);		

	skb = alloc_can_err_skb(ndev, &frame);

	if (unlikely(!skb))
		return work_done;

	frame->can_id |= CAN_ERR_CRTL;
	frame->data[1] = CAN_ERR_CRTL_RX_OVERFLOW;

	stats->rx_errors++;
	stats->rx_over_errors++;
	netif_receive_skb(skb);

	return ++work_done;
}

static int ifi_can_handle_lec_err(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	struct net_device_stats *stats = &ndev->stats;
	struct can_frame *cf;
	struct sk_buff *skb;
	canid_t id;
	u32 errcntr;
	int work_done = 0;
	const u32 errmask = IFI_CAN_ERR_ACK  |
			    IFI_CAN_ERR_BIT0 |
			    IFI_CAN_ERR_BIT1 |
			    IFI_CAN_ERR_CRC  |
			    IFI_CAN_ERR_FORM |
			    IFI_CAN_ERR_STUFF;

	/* nothing should be sent while in BUS_OFF state */
	if (priv->can.state == CAN_STATE_BUS_OFF)
		return work_done;

	errcntr = ioread32(priv->base + IFI_CAN_ERRORDETAIL);
	if (!(errcntr & errmask))	/* No error happened. */
		return work_done;

	/* Propagate the error condition to the CAN stack. */
	skb = alloc_can_err_skb(ndev, &cf);
	if (unlikely(!skb))
		return work_done;

	/* Read the error counter register and check for new errors. */
	id = cf->can_id;
	cf->can_id |= CAN_ERR_PROT;

	if (errcntr & IFI_CAN_ERR_ACK) {
		cf->can_id = (id | CAN_ERR_ACK);
		cf->data[3] = CAN_ERR_PROT_LOC_ACK;
	}

	if (errcntr & IFI_CAN_ERR_BIT0)
		cf->data[2] |= CAN_ERR_PROT_BIT0;

	if (errcntr & IFI_CAN_ERR_BIT1)
		cf->data[2] |= CAN_ERR_PROT_BIT1;

	if (errcntr & IFI_CAN_ERR_CRC)
		cf->data[3] |= CAN_ERR_PROT_LOC_CRC_SEQ;

	if (errcntr & IFI_CAN_ERR_FORM)
		cf->data[2] |= CAN_ERR_PROT_FORM;

	if (errcntr & IFI_CAN_ERR_STUFF)
		cf->data[2] |= CAN_ERR_PROT_STUFF;

	/* Reset the error counter, ack the IRQ and re-enable the counter. */
	iowrite32(errcntr | IFI_WR_ERR_RST, priv->base + IFI_CAN_ERRORDETAIL);

	stats->rx_errors++;
	stats->rx_packets++;
	stats->rx_bytes += cf->can_dlc;
	netif_receive_skb(skb);

	return ++work_done;
}

static int ifi_can_handle_state_change(struct net_device *ndev,
				       enum can_state new_state)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	struct net_device_stats *stats = &ndev->stats;
	struct can_frame *cf;
	struct sk_buff *skb;
	struct can_berr_counter bec;
	int work_done = 0;

	switch (new_state) {
	case CAN_STATE_ERROR_ACTIVE:
		/* error active state */
		priv->can.can_stats.error_warning++;
		priv->can.state = CAN_STATE_ERROR_ACTIVE;
		break;
	case CAN_STATE_ERROR_WARNING:
		/* error warning state */
		priv->can.can_stats.error_warning++;
		priv->can.state = CAN_STATE_ERROR_WARNING;
		break;
	case CAN_STATE_ERROR_PASSIVE:
		/* error passive state */
		priv->can.can_stats.error_passive++;
		priv->can.state = CAN_STATE_ERROR_PASSIVE;
		break;
	case CAN_STATE_BUS_OFF:
		/* bus-off state */
		priv->can.can_stats.bus_off++;
		priv->can.state = CAN_STATE_BUS_OFF;
		ifi_can_irq_enable(ndev, 0, 0);
		can_bus_off(ndev);
		break;
	default:
		break;
	}

	/* propagate the error condition to the CAN stack */
	skb = alloc_can_err_skb(ndev, &cf);
	if (unlikely(!skb))
		return work_done;

	ifi_can_get_berr_counter(ndev, &bec);

	switch (new_state) {
	case CAN_STATE_ERROR_WARNING:
		/* error warning state */
		cf->can_id |= CAN_ERR_CRTL;
		cf->data[1] = (bec.txerr > bec.rxerr) ?
			      CAN_ERR_CRTL_TX_WARNING : CAN_ERR_CRTL_RX_WARNING;
		cf->data[6] = bec.txerr;
		cf->data[7] = bec.rxerr;
		break;
	case CAN_STATE_ERROR_PASSIVE:
		/* error passive state */
		cf->can_id |= CAN_ERR_CRTL;
		cf->data[1] |= CAN_ERR_CRTL_RX_PASSIVE;
		if (bec.txerr > 127)
			cf->data[1] |= CAN_ERR_CRTL_TX_PASSIVE;
		cf->data[6] = bec.txerr;
		cf->data[7] = bec.rxerr;
		break;
	case CAN_STATE_BUS_OFF:
		/* bus-off state */
		cf->can_id |= CAN_ERR_BUSOFF;
		break;
	default:
		break;
	}

	stats->rx_packets++;
	stats->rx_bytes += cf->can_dlc;
	netif_receive_skb(skb);

	return ++work_done;
}

static int ifi_can_handle_error_status(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	int work_done = 0;
	u32 IntStatReg = 0;

	ifi_can_get_IntStatReg(priv, false, "ErrStat", NULL, NULL, NULL, &IntStatReg);

	if ((IntStatReg & IFI_CAN_STATUS_RD_EACT) &&
	    priv->can.state != CAN_STATE_ERROR_ACTIVE) {
		netdev_dbg(ndev, "Error: entered active state\n");
		work_done += ifi_can_handle_state_change(ndev, CAN_STATE_ERROR_ACTIVE);
	}

	if ((priv->rxIntStat & IFI_CAN_STATUS_RD_I_WARN) &&
	    priv->can.state != CAN_STATE_ERROR_WARNING) {
		netdev_dbg(ndev, "Error: entered warning state\n");
		work_done +=	ifi_can_handle_state_change(ndev, CAN_STATE_ERROR_WARNING);
		__sync_fetch_and_xor (&priv->rxIntStat, IFI_CAN_STATUS_RD_I_WARN);
	}

	if ((IntStatReg & IFI_CAN_STATUS_RD_EPAS) &&
	    priv->can.state != CAN_STATE_ERROR_PASSIVE) {
		netdev_dbg(ndev, "Error: entered passive state\n");
		work_done +=
			ifi_can_handle_state_change(ndev,
						    CAN_STATE_ERROR_PASSIVE);
	}
	/* using priv->busoff_enabled flag here as IFI_CAN_STATUS
	 * register gets cleared before this step
	 */
	if ((priv->rxIntStat & IFI_CAN_STATUS_RD_I_BOFF) &&
	    priv->can.state != CAN_STATE_BUS_OFF) {
		netdev_dbg(ndev, "Error: entered bus-off state\n");
		work_done +=
			ifi_can_handle_state_change(ndev,
						    CAN_STATE_BUS_OFF);
		__sync_fetch_and_xor(&priv->rxIntStat, IFI_CAN_STATUS_RD_I_BOFF);
	}

	return work_done;
}

static void ReadMsgCount ( struct ifi_can_priv *priv, u16 * pRxCount, u16 * pTxCount)
{
	volatile u32 ifi_reg_fifo = 0;
	volatile u32 rx_msg_count = 0;
	volatile u32 tx_msg_count = 0;

	unsigned long spin_flags;
	spin_lock_irqsave(&priv->status_lock, spin_flags);

	ifi_reg_fifo = ioread32(priv->base + IFI_CAN_FIFO_PNTR);
	rx_msg_count = ((ifi_reg_fifo & IFI_CAN_FIFO_PTR_RD_RBC)
			     >> IFI_CAN_FIFO_RX_OFF);	
	tx_msg_count = ((ifi_reg_fifo & IFI_CAN_FIFO_PTR_RD_TBC)
			     >> IFI_CAN_FIFO_TX_OFF);					 

	if (pRxCount) 
		*pRxCount = (u16) rx_msg_count;
	
	if (pTxCount) 
		*pTxCount = (u16) tx_msg_count;

	spin_unlock_irqrestore(&priv->status_lock, spin_flags);	
}

static void ResetRxBuffer ( struct ifi_can_priv *priv)
{
	volatile u32 regVal = 0;
	int iCount = 0;
	u16 rxCount = 1;

//	unsigned long spin_flags;
//	spin_lock_irqsave(&priv->status_lock, spin_flags);	

	//IFI_CAN_FIFO_PTR_WR_RTB
	regVal = IFI_CAN_FIFO_PTR_WR_RRB;

	iowrite32( regVal, priv->base + IFI_CAN_FIFO_PNTR);

	while ( ( ++iCount < 100 ) && (rxCount > 0)){
		ReadMsgCount (priv, &rxCount, NULL );
	};
	iowrite32(0, priv->base + IFI_CAN_FIFO_PNTR);

//	spin_unlock_irqrestore(&priv->status_lock, spin_flags);		
}


static bool ifi_can_read_fifo(struct net_device *ndev)
{
	bool fRet = false;
	int ret;
	struct net_device_stats *stats = &ndev->stats;
	struct ifi_can_priv *priv = netdev_priv(ndev);
	struct can_frame *cf;
	struct sk_buff *skb = NULL;
	u32 swap_id;
	int i;
	volatile u32 StatReg = 0;	
	volatile u32 dlcReg  = 0;
	volatile u32 idReg   = 0;
	volatile u32 dataReg = 0;
	u16 rx_msg_count = 0;
	u32 dlc = 0;
	u32 frn = 0;
	u32 id = 0;	

	ReadMsgCount (priv, &rx_msg_count, NULL);	
				 
	if (rx_msg_count == 0) {
		netdev_dbg(ndev, "No messages in RX FIFO\n");
		fRet = false;
	}
	else {
		dlcReg = ioread32(priv->base + IFI_CAN_DLC);
		idReg  = ioread32(priv->base + IFI_CAN_IDENTIFER);

		dlc   = (dlcReg & IFI_CAN_DLC_MASK) >> IFI_CAN_DLC_S;
		frn   = (dlcReg & IFI_CAN_DLC_FRN) >> IFI_CAN_FRN_S;

		id = (idReg >> IFI_CAN_ID_S);
		
		// self reception message
		if (frn) {
			ret = ixx_can_get_echo_skb(ndev, frn);

			// PACKET_LOOPBACK is set and the
			if (ret)
				stats->tx_bytes += ret;
			else
				stats->tx_bytes += dlc;

			stats->tx_packets++;
			ifi_can_msg_free_idx(ndev, frn);
			fRet = true;

		} else {
			skb = alloc_can_skb(ndev, &cf);
			
			if (unlikely(!skb)) {
				stats->rx_dropped++;
				fRet = false;
			} else {


				cf->can_dlc = can_cc_dlc2len(dlc);

				/* In case the Extended ID frame is received, the standard
				* and extended part of the ID are swapped in the register,
				* so swap them back to obtain the correct ID.
				*/
				if (id & IFI_CAN_ID_IDE) {
					swap_id = ((id & IFI_CAN_IDEXT_00_17) >> IFI_CAN_ID_EXT_OFF)
						+ ((id & IFI_CAN_ID_STD) << IFI_CAN_ID_EXT_WIDTH);
					swap_id |= CAN_EFF_FLAG;
				} else {
					id &= IFI_CAN_ID_STD;
					swap_id = id;
				}

				cf->can_id = swap_id;

				if (dlcReg & IFI_CAN_DLC_RTR)
					cf->can_id |= CAN_RTR_FLAG;
				else
					for (i = 0; i < cf->can_dlc; i += sizeof(u32)) {
						dataReg = ioread32(priv->base + IFI_CAN_DATA14 + i);
						*(u32 *)(cf->data + i) = dataReg;
					}

				stats->rx_packets++;
				stats->rx_bytes += cf->can_dlc;

				if ( NET_RX_SUCCESS == netif_receive_skb(skb))
					fRet = true;
			}
		}
	}

	if (fRet) {
		StatReg = IFI_CAN_STATUS_WR_NEXT;
		ifi_can_set_IntStatReg (priv, StatReg, false, "rxPoll");

		++ priv->isrRxMsgTrue;
	}
	else {
		++ priv->isrRxMsgFalse;
	}


	return fRet;
}



static int ifi_can_do_rx_poll(struct net_device *ndev, int quota)
{
	u32 pkts = 0;

	while (quota > 0) {
		if ( ifi_can_read_fifo(ndev)) {
			quota--;
			pkts++;
		}
		else {
			// alloc_can_skb failed or nothing received !
			break; 
		}
	} 

	if (pkts)
		can_led_event(ndev, CAN_LED_EVENT_RX);

	return pkts;
}

int ifi_can_poll(struct napi_struct *napi, int quota)
{
	struct net_device *ndev = napi->dev;
	struct ifi_can_priv *priv = netdev_priv(ndev);
	int work_done = 0;
	u32 MsgNum, MsgNumRx;
	static int count = 0;


	++ priv->napiCountIn;

  // store the RX interrupt for later use */
	if (priv->rxIntStat) {
		/* Handle bus state changes */
		work_done += ifi_can_handle_error_status(ndev);

		/* Handle lost messages on RX */
		if (priv->rxIntStat & IFI_CAN_STATUS_RD_I_RBO) {
			ResetRxBuffer(priv);
			work_done += ifi_can_handle_lost_msg(ndev);
			
			__sync_fetch_and_xor(&priv->rxIntStat, IFI_CAN_STATUS_WR_I_RBO);
		}

		if (priv->rxIntStat & IFI_CAN_STATUS_RD_I_ERR ) {
			// Handle lec errors on the bus 
			if (priv->can.ctrlmode & CAN_CTRLMODE_BERR_REPORTING)
				work_done += ifi_can_handle_lec_err(ndev); //Done
			__sync_fetch_and_xor(&priv->rxIntStat, IFI_CAN_STATUS_RD_I_ERR);
		}

		/* Handle normal messages on RX */
		if (priv->rxIntStat & IFI_CAN_STATUS_RD_I_RNE ) {
			MsgNum = quota - work_done;
			MsgNumRx = ifi_can_do_rx_poll(ndev, MsgNum);
			work_done += MsgNumRx;

			if (MsgNumRx < MsgNum) {
				__sync_fetch_and_xor(&priv->rxIntStat, IFI_CAN_STATUS_RD_I_RNE);
			}
		}

		if (priv->rxIntStat & IFI_CAN_STATUS_RD_I_RBF)
			__sync_fetch_and_xor(&priv->rxIntStat, IFI_CAN_STATUS_RD_I_RBF);

		if (work_done < quota) {

			if (priv->rxIntStat) {
				// signal that still work is to be done
				work_done = quota;
			}
			else {
				++priv->napiCountFinish;
				napi_complete_done(napi, work_done);
				ifi_can_irq_enable(ndev, 1, 0);
			}	
		}
		else {
			++priv->napiCountFull;
		}
	}
	else {
		++priv->napiCountFinish;
		napi_complete_done(napi, work_done);
		ifi_can_irq_enable(ndev, 1, 0);
	}

	++priv->napiCountOut;
	++count;

	return work_done;
}
EXPORT_SYMBOL_GPL(ifi_can_poll);

void ifi_can_set_filter(struct net_device *ndev, const u32 id,
			       bool enable, u32 mask, u32 ident)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);

	if (!enable) {
		mask = 0;
		ident = 0;
	}

	iowrite32(mask, priv->base + IFI_CAN_FILTER_MASK(id));
	iowrite32(ident, priv->base + IFI_CAN_FILTER_IDENT(id));
}



void ifi_can_set_filters(struct net_device *ndev, bool enable)
{
	/* Receive all CAN frames (standard ID) */
	ifi_can_set_filter(ndev, 0, enable,
			   IFI_CAN_RD_FMVALID | IFI_CAN_RD_FMEXT,
			   IFI_CAN_RD_FIDVALID);

	/* Receive all CAN frames (extended ID) */
	ifi_can_set_filter(ndev, 1, enable,
			   IFI_CAN_RD_FMVALID | IFI_CAN_RD_FMEXT,
			   IFI_CAN_RD_FIDVALID | IFI_CAN_RD_FIDEXT);
}
EXPORT_SYMBOL_GPL(ifi_can_set_filters);


static void ifi_can_irq_clear(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	u32 ifi_reg_status, ifi_reg_errordetail = 0;

	unsigned long spin_flags;

	spin_lock_irqsave(&priv->status_lock, spin_flags);	

	ifi_reg_status = ioread32(priv->base + IFI_CAN_STATUS);

	/* Clear pending IFI CAN controller interrupts */

	iowrite32(ifi_reg_status, priv->base + IFI_CAN_STATUS);

	/* Reset Error register */
	ifi_reg_errordetail = ioread32(priv->base + IFI_CAN_ERRORDETAIL);
	ifi_reg_errordetail |= IFI_WR_ERR_RST;
	iowrite32(ifi_reg_errordetail, priv->base + IFI_CAN_ERRORDETAIL);

	spin_unlock_irqrestore(&priv->status_lock, spin_flags);		
}

inline bool ifi_can_get_IntEnaReg(struct ifi_can_priv *priv , 
						bool fForce,
						char * szText, u32 * pRxInt, u32 * pTxInt, u32 * pIntEnaReg)
{
	bool fRet = false;
	volatile u32 ifi_reg_status = 0;
	u32 uRxInt;
	u32 uTxInt;
	unsigned long spin_flags;

	const u32 rx_irq_mask = IXXAT_IF_RX_RD_MASK;
	const u32 tx_irq_mask = IXXAT_IF_TX_RD_MASK;

	spin_lock_irqsave(&priv->status_lock, spin_flags);

	ifi_reg_status = ioread32(priv->base + IFI_CAN_INTMASK);

	uTxInt = ifi_reg_status & tx_irq_mask;
	if ((uTxInt != 0 ) && (pTxInt)) {
		*pTxInt = uTxInt;
		fRet = true;		
	}

	uRxInt = ifi_reg_status & rx_irq_mask;
	if ((uRxInt != 0 ) && ( pRxInt )) {
		*pRxInt = uRxInt;
		fRet = true;
	}

	if ( pIntEnaReg ) 
		*pIntEnaReg = ifi_reg_status;		

	spin_unlock_irqrestore(&priv->status_lock, spin_flags);		
	
//	ix_trace_printk (" Irq Status %i, Rx: %x, Tx: %x\n", fRet, uRxInt, uTxInt);
	if ((priv->debugOn) || fForce ){
		ix_trace_printk ("%s: Irq Enable %i, Rx: %x, Tx: %x, Reg: %x\n", 
				szText, fRet, uRxInt, uTxInt, ifi_reg_status);
	}
	
	return fRet;		
}	
EXPORT_SYMBOL_GPL(ifi_can_get_IntEnaReg);			

bool ifi_can_get_IntStatReg(struct ifi_can_priv *priv , 
						bool fForce, char * szText,
						u32 * pRxInt, u32 * pTxInt, u32 * pOtherInt, u32 * pIntStatReg )
{
	bool fRet = false;
	volatile u32 ifi_reg_status = 0;
	u32 uRxInt;
	u32 uTxInt;
	u32 uOtherInt;
	unsigned long spin_flags;

	const u32 rx_irq_mask = IXXAT_IF_RX_RD_MASK;
	const u32 tx_irq_mask = IXXAT_IF_TX_RD_MASK;

	spin_lock_irqsave(&priv->status_lock, spin_flags);

	ifi_reg_status = ioread32(priv->base + IFI_CAN_STATUS);

	uTxInt = ifi_reg_status & tx_irq_mask;
	if ((uTxInt != 0 ) && (pTxInt)) {
		*pTxInt = uTxInt;
		fRet = true;		
	}

	uRxInt = ifi_reg_status & rx_irq_mask;
	if ((uRxInt != 0 ) && ( pRxInt )) {
		*pRxInt = uRxInt;
		fRet = true;
	}

	uOtherInt = ifi_reg_status & ~(tx_irq_mask | rx_irq_mask);
	if ((uOtherInt != 0 ) && ( pOtherInt )) {
		*pOtherInt = uOtherInt;
		fRet = true;
	}	
	if ( pIntStatReg ) 
		*pIntStatReg = ifi_reg_status;		

	spin_unlock_irqrestore(&priv->status_lock, spin_flags);		
	
	if ( (priv->debugOn) || fForce) {
		ix_trace_printk ("%s: Irq Status %i, Rx: %x, Tx: %x, Other: %x, Reg: %x\n", 
				szText, fRet, uRxInt, uTxInt, uOtherInt, ifi_reg_status);
	}
	
	return fRet;
}
EXPORT_SYMBOL_GPL(ifi_can_get_IntStatReg);

bool ifi_can_set_IntStatReg (struct ifi_can_priv *priv , 
									const u32 IntStatReg, 
									bool fForce, char * szText )
{
	unsigned long spin_flags;
	spin_lock_irqsave(&priv->status_lock, spin_flags);
	iowrite32( IntStatReg, priv->base + IFI_CAN_STATUS);
	spin_unlock_irqrestore(&priv->status_lock, spin_flags);		

	if ( (priv->debugOn) || fForce) {		
		trace_printk ("%s: ifi_can_set_IntStatReg %x  \n", szText, IntStatReg);
	}
	return true;
}
EXPORT_SYMBOL_GPL(ifi_can_set_IntStatReg);


void ifi_can_irq_enable(struct net_device *ndev, bool enable, u8 clear)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	volatile u32 enirq = IFI_CAN_INTMASK_WR_SEM  |
		IFI_CAN_INTMASK_WR_SEIM |
		IFI_CAN_INTMASK_WR_STOK |
		IFI_CAN_INTMASK_WR_SBM;

	unsigned long spin_flags;

	if (enable) {
		if (clear)
			ifi_can_irq_clear(ndev);

		spin_lock_irqsave(&priv->status_lock, spin_flags);		
		enirq |= IXXAT_IF_TX_WR_ENA;
		iowrite32(enirq, priv->base + IFI_CAN_INTMASK);
		spin_unlock_irqrestore(&priv->status_lock, spin_flags);		
	}
	else
	{
		spin_lock_irqsave(&priv->status_lock, spin_flags);		
		iowrite32(enirq, priv->base + IFI_CAN_INTMASK);
		spin_unlock_irqrestore(&priv->status_lock, spin_flags);		

		if (clear)
			ifi_can_irq_clear(ndev);
	}


	
}
EXPORT_SYMBOL_GPL(ifi_can_irq_enable);

void ifi_can_timer (struct timer_list * data)
{
	u32 uRxInt = 0;
	u32 uTxInt = 0;
	u32 uOtherInt = 0;
	u32 IntStatReg = 0;	
	u16 tx_msg_count = 0;

	struct ifi_can_priv *priv = from_timer (priv, data, tList);
	if (data) {

		if (ifi_can_get_IntStatReg( priv, false, "timer", &uRxInt, &uTxInt, &uOtherInt, NULL)) {

			if (uTxInt) {
				netif_wake_queue(priv->ndev);
			}
			else {
				ReadMsgCount (priv, NULL, &tx_msg_count);	

				if ( tx_msg_count <= 2)
					netif_wake_queue(priv->ndev);
			}

			if (uRxInt) {
      // store the RX interrupt for later use */
      __sync_fetch_and_or(&priv->rxIntStat, uRxInt);
				napi_schedule(&priv->napi);
			}

			IntStatReg = (uTxInt | uRxInt| uOtherInt);
    		ifi_can_set_IntStatReg(priv, IntStatReg, false, "isr");			
		}
	}

	mod_timer (&priv->tList, jiffies + msecs_to_jiffies(IXXAT_TIMER));
}
EXPORT_SYMBOL_GPL(ifi_can_timer);


irqreturn_t ifi_can_isr(int irq, void *dev_id)
{
	irqreturn_t iRet = IRQ_NONE;
	struct net_device *ndev = (struct net_device *)dev_id;
	struct ifi_can_priv *priv = netdev_priv(ndev);
	u32 uRxInt = 0;
	u32 uTxInt = 0;
	u32 uOtherInt = 0;
	u32 IntStatReg;

	++priv->isrCountIn;

	if (priv->pre_irq)
		priv->pre_irq(priv);

	if (ifi_can_get_IntStatReg( priv, false, "ISR", &uRxInt, &uTxInt, &uOtherInt, NULL)) {

		// store the RX interrupt for later use */
		__sync_fetch_and_or(&priv->rxIntStat, uRxInt);

		/* TX IRQ */
		if (uTxInt) {
			can_led_event(ndev, CAN_LED_EVENT_TX);
			netif_wake_queue(ndev);
			++priv->isrCountNapiTx;
		}

		/* RX IRQ or bus warning, start NAPI */
		if (uRxInt) {
			// disable interrupt 
			ifi_can_irq_enable(ndev, 0, 0);

			++priv->isrCountNapi;
			napi_schedule(&priv->napi);
			++priv->isrCountNapiAfter;
		}
		else {
			++priv->isrCountNapiRxNot;
		}

    /* Clear Interrupts */
		IntStatReg = (uTxInt | uRxInt);
    	ifi_can_set_IntStatReg(priv, IntStatReg, false, "isr");
		iRet = IRQ_HANDLED;
	}

	if (priv->post_irq)
		priv->post_irq(priv);	

	++priv->isrCountOut;
		
	return iRet;
}

void ifi_can_set_bittiming(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	const struct can_bittiming *bt = &priv->can.bittiming;
	volatile u32 ifi_time_control = 0;

	ifi_time_control = ((bt->brp - ifi_can_bittiming_const.brp_min)
		<< IFI_CAN_TC_PRESCALE_OFF) & IFI_CAN_TC_PRESCALE;
	ifi_time_control |= IFI_CAN_TC_S_PRESCALE;
	ifi_time_control |= ((bt->sjw - 1) << IFI_CAN_TC_SJW_OFF) &
		IFI_CAN_TC_SJW;
	ifi_time_control |= IFI_CAN_TC_S_SJW;
	ifi_time_control |= (((bt->phase_seg1 + bt->prop_seg)
		- ifi_can_bittiming_const.tseg1_min) <<
		IFI_CAN_TC_TIMEA_OFF) & IFI_CAN_TC_TIMEA;
	ifi_time_control |= IFI_CAN_TC_S_TIMEA;
	ifi_time_control |= ((bt->phase_seg2 -
		ifi_can_bittiming_const.tseg2_min)	<<
		IFI_CAN_TC_TIMEB_OFF) & IFI_CAN_TC_TIMEB;
	ifi_time_control |= IFI_CAN_TC_S_TIMEB;
	iowrite32(ifi_time_control, priv->base + IFI_CAN_TC);
}

static void ifi_can_start(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	u32 ifi_timing_ctrl = IFI_CAN_TC_S_SMODE | IFI_CAN_TC_NORMAL_MODE;
	u32 ifi_hardreset = ioread32(priv->base + IFI_CAN_HARDRESET);
	u32 ifi_error_detail = ioread32(priv->base + IFI_CAN_ERRORDETAIL);
	
	if (priv->can.ctrlmode & CAN_CTRLMODE_LOOPBACK) { // Loopback mode
		priv->loopback = true;
	} else {
		priv->loopback = false;
	}	

	priv->rxIntStat = 0;

	priv->isrCountIn = 0;
	priv->isrCountNapi = 0;
	priv->isrCountNapiAfter = 0;
	priv->isrCountOut = 0;
	priv->isrCountNapiTx = 0;
	priv->isrCountNapiRxNot = 0;	

	priv->isrRxMsgTrue = 0;
	priv->isrRxMsgFalse = 0;

	priv->napiCountIn = 0;
	priv->napiCountOut = 0;
	priv->napiCountFinish = 0;
	priv->napiCountFull = 0;

	priv->debugOn = false;

	ifi_error_detail |= IFI_WR_ERR_RST;
	/* Setting silent Mode */
	if (priv->can.ctrlmode & CAN_CTRLMODE_LISTENONLY)
		ifi_timing_ctrl |= IFI_CAN_TC_SILENT_MODE;

	if ((ifi_hardreset & IFI_CAN_RD_RESET) == IFI_NO_HARDRESET)
		iowrite32(IFI_CAN_RST_WR_EN, priv->base + IFI_CAN_HARDRESET);

	iowrite32(IFI_CAN_RST_WR_DISABLE, priv->base + IFI_CAN_HARDRESET);
	iowrite32(ifi_timing_ctrl, priv->base + IFI_CAN_TC);

	/* Setting One-shot/BERR reporting Mode */
	if (priv->can.ctrlmode & CAN_CTRLMODE_ONE_SHOT)
		ifi_error_detail |= IFI_WR_SSM;

	if (priv->can.ctrlmode & CAN_CTRLMODE_BERR_REPORTING)
		ifi_error_detail |= IFI_WR_ERR_ENA;

	iowrite32(ifi_error_detail, priv->base + IFI_CAN_ERRORDETAIL);

	ifi_can_set_bittiming(ndev);
	ifi_can_set_filters(ndev, 1);

	priv->can.state = CAN_STATE_ERROR_ACTIVE;

	priv->rxIntStat = 0;
	ifi_can_irq_enable(ndev, 1, 1);
	mod_timer (&priv->tList, jiffies + msecs_to_jiffies(IXXAT_TIMER ));
}

static void ifi_can_stop(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	int i = 0;
	u32 ifi_timing_ctrl = IFI_CAN_TC_S_SMODE | IFI_CAN_TC_SILENT_MODE |
			      IFI_CAN_TC_NORMAL_MODE;
	u32 ifi_error_detail = IFI_WR_ERR_RST;

	del_timer (&priv->tList);

	/*Enable Hard Reset*/
	iowrite32(IFI_CAN_RST_WR_EN, priv->base + IFI_CAN_HARDRESET);

	iowrite32(ifi_timing_ctrl, priv->base + IFI_CAN_TC);
	iowrite32(ifi_error_detail, priv->base + IFI_CAN_ERRORDETAIL);
	ifi_can_set_filters(ndev, 0);

	iowrite32(IFI_CAN_FIFO_PTR_WR_RTB | IFI_CAN_FIFO_PTR_WR_RRB,
		  priv->base + IFI_CAN_FIFO_PNTR);
	iowrite32(IFI_CAN_TC_RPMSG, priv->base + IFI_CAN_TC);

	do {
	} while ((IFI_CAN_STATUS_RD_MSG &
		  ioread32(priv->base + IFI_CAN_STATUS)) &&
		  i++ < IXXAT_PCI_TIMEOUT);

	iowrite32(0, priv->base + IFI_CAN_FIFO_PNTR);
}

static void ifi_can_restart(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	int i;

	ifi_can_stop(ndev);

	for (i = 0; i < priv->can.echo_skb_max; ++i)
		ixx_can_free_echo_skb(priv->ndev, i);

	ifi_can_msg_free_idx(priv->ndev, 0xFFFFFFFF);

	ifi_can_start(ndev);
	netif_wake_queue(priv->ndev);
}

static int ifi_can_set_mode(struct net_device *ndev, enum can_mode mode)
{
	switch (mode) {
	case CAN_MODE_START:
		ifi_can_restart(ndev);
		break;
	default:
		return -EOPNOTSUPP;
	}

	return 0;
}

struct net_device *alloc_ifi_can_dev(int sizeof_priv, int echo_skb_max)
{
	struct ifi_can_priv *priv;
	struct net_device *ndev;

	if (echo_skb_max > 64)
		echo_skb_max = 64;

	ndev = alloc_candev(sizeof(struct ifi_can_priv)
		+ sizeof_priv, echo_skb_max);

	if (!ndev)
		return NULL;

	priv = netdev_priv(ndev);
	priv->ndev = ndev;
	priv->msgs = 0;
	priv->msg_index = 0;

	priv->can.bittiming_const = &ifi_can_bittiming_const;
	priv->can.do_set_mode = ifi_can_set_mode;
	priv->can.do_get_berr_counter = ifi_can_get_berr_counter;
	priv->can.restart_ms = IFI_CAN_DEFAULT_RESTART_MS;

	priv->can.ctrlmode_supported = CAN_CTRLMODE_ONE_SHOT |
		CAN_CTRLMODE_LISTENONLY |
		CAN_CTRLMODE_LOOPBACK |
		CAN_CTRLMODE_BERR_REPORTING;

	spin_lock_init(&priv->recv_lock);
	spin_lock_init(&priv->status_lock);

	ifi_can_msg_free_idx(ndev, 0xFFFFFFFF);

	return ndev;
}
EXPORT_SYMBOL_GPL(alloc_ifi_can_dev);

void free_ifi_can_dev(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	del_timer (&priv->tList);

	free_candev(ndev);
}
EXPORT_SYMBOL_GPL(free_ifi_can_dev);

static int ifi_can_open(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	int ret = open_candev(ndev);
	
	if (ret)
		return ret;

	/* Register interrupt handler */
	if (!(priv->flags & IFI_CAN_CUSTOM_IRQ_HANDLE)) {
		ret = request_irq(ndev->irq, ifi_can_isr, IRQF_SHARED,
				  ndev->name, ndev);

		if (ret < 0) {
			netdev_err(ndev,
				   "Error %i:Request Interrupt failed\n", ret);
			goto err_irq;
		}
	}

	ifi_can_start(ndev);

	can_led_event(ndev, CAN_LED_EVENT_OPEN);
	napi_enable(&priv->napi);
	netif_start_queue(ndev);
	return 0;

err_irq:
	close_candev(ndev);
	
	return ret;
}

static int ifi_can_close(struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);

	netif_stop_queue(ndev);
	napi_disable(&priv->napi);

	ifi_can_stop(ndev);
	priv->can.state = CAN_STATE_STOPPED;
	ifi_can_irq_enable(ndev, 0, 1);

	if (!(priv->flags & IFI_CAN_CUSTOM_IRQ_HANDLE))
		free_irq(ndev->irq, ndev);

	close_candev(ndev);
	can_led_event(ndev, CAN_LED_EVENT_STOP);

	return 0;
}

static bool ifi_can_DebugExt ( struct ifi_can_priv *priv, u32 canId )
{
	bool fRet = false;
	u32 txid = canId & CAN_SFF_MASK;
	u32 txid_ext = canId & ~CAN_SFF_MASK;

	if ( txid_ext == 0x0800) {
		if (txid == 0)
		{
			ix_trace_printk ("Xmit Isr In:%i, Out:%i, napi:(%i,%i), Rx N: %i, Tx: %i\n", 
						priv->isrCountIn, 
						priv->isrCountOut,
						priv->isrCountNapi, 
						priv->isrCountNapiAfter,
						priv->isrCountNapiRxNot,
						priv->isrCountNapiTx );
			ix_trace_printk ("Xmit Napi In:%i, Out:%i, finish:%i, full: %i\n", 
						priv->napiCountIn, 
						priv->napiCountOut, 
						priv->napiCountFinish,
						priv->napiCountFull);
			ix_trace_printk ("Rx True:%i, False:%i\n", 
						priv->isrRxMsgTrue, 
						priv->isrRxMsgFalse);						
		}	
		else if (txid == 1){
			if (priv->chk_irq)
				priv->chk_irq(priv);	
		}
		else if (txid == 2){
			priv->debugOn = true;
		} else if (txid == 3){
			priv->debugOn = false;
		}
		else if (txid == 4){
			napi_schedule(&priv->napi);
		}
		else if (txid == 5){
			// reset interrupts !
			ifi_can_set_IntStatReg (priv, IXXAT_IF_RX_RD_MASK, false, "xmit");
		}	
		
		fRet = true;
	}

	return fRet;
}

static netdev_tx_t ifi_can_start_xmit(struct sk_buff *skb,
				      struct net_device *ndev)
{
	struct ifi_can_priv *priv = netdev_priv(ndev);
	struct can_frame *cf = (struct can_frame *)skb->data;
	u32 txid, txdlc;
	int i;
	unsigned long spin_flags;
	u32 MsgIdx;
	u32 uIntStat = 0;
	bool fTransmit = true;

	if (can_dropped_invalid_skb(ndev, skb))
		return NETDEV_TX_OK;

	ifi_can_get_IntStatReg (priv, false, "xmit", NULL, NULL, NULL, &uIntStat);

	/* Check if the TX buffer is full */
	spin_lock_irqsave(&priv->recv_lock, spin_flags);
	
	if (uIntStat & IFI_CAN_STATUS_RD_TBF) {
		netif_stop_queue(ndev);
		netdev_err(ndev, "Error: TX FIFO full when queue awake.\n");
		spin_unlock_irqrestore(&priv->recv_lock, spin_flags);
		return NETDEV_TX_BUSY;
	}

	MsgIdx = ifi_can_msg_get_next_idx(ndev);

	if (MsgIdx == IFI_CAN_E_FAILED) {
		netif_stop_queue(ndev);
		//netdev_err(ndev, "Error: No free Message idx available.\n");
		ix_trace_printk ("Error: No free Message idx available.\n");
		spin_unlock_irqrestore(&priv->recv_lock, spin_flags);
		return NETDEV_TX_BUSY;
	}

	spin_unlock_irqrestore(&priv->recv_lock, spin_flags);
	

	/* In case the Extended ID frame is transmitted, the
	 * standard and extended part of the ID are swapped
	 * in the register, so swap them back to send the
	 * correct ID
	 */
	fTransmit = true;

	if (cf->can_id & CAN_EFF_FLAG) {
		txid = cf->can_id & CAN_EFF_MASK;
		txid = (txid >> IFI_CAN_ID_EXT_WIDTH) |
				((txid & CAN_EFF_MASK) << IFI_CAN_ID_EXT_OFF);
		txid |= IFI_CAN_ID_IDE;
	} else {
		txid = cf->can_id & CAN_SFF_MASK;
		
		if ( ifi_can_DebugExt ( priv, cf->can_id )) {
			fTransmit = false;
		}
	}

	if ( fTransmit ) {
		txdlc = cf->can_dlc & IFI_CAN_DLC_MASK;

		if (cf->can_id & CAN_RTR_FLAG)
			txdlc |= IFI_CAN_DLC_RTR;
		else
			txdlc &= IFI_CAN_DLC_MASK;

		if (priv->can.ctrlmode & CAN_CTRLMODE_ONE_SHOT)
			txdlc |= IFI_CAN_DLC_SSM;

		txdlc &= ~(IFI_CAN_DLC_FRN);
		txdlc |= (MsgIdx << IFI_CAN_FRN_S);

		for (i = 0; i < cf->can_dlc; i += sizeof(u32))
			iowrite32(*(u32 *)(cf->data + i), priv->base
				+ IFI_CAN_DATA14 + i);

		iowrite32(txid, priv->base + IFI_CAN_IDENTIFER);
		iowrite32(txdlc, priv->base + IFI_CAN_DLC);

		// PACKET_LOOPBACK flag is checked in the function can_put_
		ixx_can_put_echo_skb(skb, ndev, MsgIdx);
	}


	return NETDEV_TX_OK;
}

static const struct net_device_ops ifi_can_netdev_ops = {
	.ndo_open	= ifi_can_open,
	.ndo_stop	= ifi_can_close,
	.ndo_start_xmit	= ifi_can_start_xmit,
	.ndo_change_mtu	= can_change_mtu,
};

int register_ifi_can_dev(struct net_device *ndev)
{
	int ret;

	ndev->netdev_ops = &ifi_can_netdev_ops;
	ndev->flags |= IFF_ECHO;

	ret =  register_candev(ndev);
	if (!ret)
		devm_can_led_init(ndev);

	return ret;
}
EXPORT_SYMBOL_GPL(register_ifi_can_dev);

void unregister_ifi_can_dev(struct net_device *ndev)
{
	unregister_candev(ndev);
}
EXPORT_SYMBOL_GPL(unregister_ifi_can_dev);

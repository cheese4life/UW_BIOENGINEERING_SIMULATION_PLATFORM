/* SPDX-License-Identifier: GPL-2.0 */

/* CAN driver base for IXXAT PCI-to-CAN
 *
 * Copyright (C) 2018 HMS Industrial Networks <socketcan@hms-networks.de>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published
 * by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 */

#ifndef IFI_CAN_H_
#define IFI_CAN_H_

#include "../../../../../../common/ixxat_functions.h"

/********* Data Length Code - Offset 0 *********/
#define IFI_CAN_DLC			0x00

#define IFI_CAN_DLC_MASK		0x0000000F
#define IFI_CAN_DLC_RTR			BIT(4)
#define IFI_CAN_DLC_OBJ			0x0001FF00    /* Read-Only */
#define IFI_CAN_DLC_SSM			0x00800000
#define IFI_CAN_DLC_FRN			0xFF000000

#define IFI_CAN_DLC_S			0
#define IFI_CAN_RTR_S			4
#define IFI_CAN_OBJ_S			8
#define IFI_CAN_SSM_S			23
#define IFI_CAN_FRN_S			24
/********* Identifier - Offset 1 *********/
#define IFI_CAN_IDENTIFER		0x04

#define IFI_CAN_ID_IDE			BIT(29)
#define IFI_CAN_ID_EXT_OFF		11
#define IFI_CAN_ID_EXT_WIDTH		18
#define IFI_CAN_ID				0x1FFFFFFF
#define IFI_CAN_ID_STD			0x000007FF
#define IFI_CAN_IDEXT_00_17		0x1FFFF800

#define IFI_CAN_ID_S			0
#define IFI_CAN_IDSTD_S			0
#define IFI_CAN_IDEXT_18_28_S		0
#define IFI_CAN_IDEXT_00_17_S		11
#define IFI_CAN_IDE_S			29

/********* Data Bytes 1-4 - Offset 2 *********/
#define IFI_CAN_DATA14			0x08
/********* Data Bytes 5-8 - Offset 3 *********/
#define IFI_CAN_DATA58			0x0C

/********* Timing and Control - Offset 4 *********/
#define IFI_CAN_TC			0x10

#define IFI_CAN_TC_TIMEB		0x0000001F  // Time B
#define IFI_CAN_TC_SJW			0x00000060  // SJW
#define IFI_CAN_TC_S_TIMEB		BIT(7)      // Set Time B
#define IFI_CAN_TC_TIMEA		0x00001F00  // Time A
#define IFI_CAN_TC_S_SJW		BIT(14)     // Set SJW
#define IFI_CAN_TC_S_TIMEA		BIT(15)     // set Time A
#define IFI_CAN_TC_PRESCALE		0x00FF0000  // prescaler
#define IFI_CAN_TC_NORMAL_MODE		BIT(24)     // normal mode
#define IFI_CAN_TC_HIGH_PRIORITY	BIT(26)     // high priority message
#define IFI_CAN_TC_RD_SJW		0x06000000  // Read SJW
#define IFI_CAN_TC_TS_RESET		BIT(27)     // Timestamp counter reset
#define IFI_CAN_TC_SILENT_MODE		BIT(28)     // silent mode
#define IFI_CAN_TC_RPMSG		BIT(29)     // remove pending message
#define IFI_CAN_TC_S_SMODE		BIT(30)     // set silent mode
#define IFI_CAN_TC_S_PRESCALE		((u32)BIT(31))  // set prescaler

#define IFI_CAN_TC_TIMEB_OFF		0
#define IFI_CAN_TC_TIMEA_OFF		8
#define IFI_CAN_TC_PRESCALE_OFF		16
#define IFI_CAN_TC_SJW_OFF		5

/********* Interrupt Mask - Offset 5 *********/
#define IFI_CAN_INTMASK			0x14

#define IFI_CAN_INTMASK_RD_BO		BIT(0)  //Bus Off
#define IFI_CAN_INTMASK_RD_EW		BIT(1)  //Error Warning
#define IFI_CAN_INTMASK_RD_TOK	BIT(14) //Transmit OK
#define IFI_CAN_INTMASK_RD_EI		BIT(16) //ErrorInformation
#define IFI_CAN_INTMASK_RD_TBE	BIT(24) //Tx buffer empty INT reset
#define IFI_CAN_INTMASK_RD_TBO	BIT(25) //Tx buf overflow INT reset
#define IFI_CAN_INTMASK_RD_TBF	BIT(26) //Tx buffer full INT reset
#define IFI_CAN_INTMASK_RD_RNE	BIT(27) //Rx buf not empty INTreset
#define IFI_CAN_INTMASK_RD_RBO	BIT(28) //Rx buf overflow INT reset
#define IFI_CAN_INTMASK_RD_RBF	BIT(29) //Rx buffer full INT reset

#define IFI_CAN_INTMASK_WR_EW		BIT(0)  //Error Warning
#define IFI_CAN_INTMASK_WR_BO		BIT(1)  //Bus Off
#define IFI_CAN_INTMASK_WR_SEM	BIT(7)  //Set Error Interrupt Mask
#define IFI_CAN_INTMASK_WR_TOK	BIT(14) //Transmit OK
#define IFI_CAN_INTMASK_WR_STOK	BIT(15) //Set Transmit OK
#define IFI_CAN_INTMASK_WR_EI		BIT(16) //ErrorInformation
#define IFI_CAN_INTMASK_WR_SEIM	BIT(23) //Set Error Info Mask
#define IFI_CAN_INTMASK_WR_TBE	BIT(24) //Tx buf empty INT reset
#define IFI_CAN_INTMASK_WR_TBO	BIT(25) //Tx buf overflow INT reset
#define IFI_CAN_INTMASK_WR_TBF	BIT(26) //Tx buffer full INT reset
#define IFI_CAN_INTMASK_WR_RNE	BIT(27) //Rx buf not empty INTreset
#define IFI_CAN_INTMASK_WR_RBO	BIT(28) //Rx buf overflow INT reset
#define IFI_CAN_INTMASK_WR_RBF	BIT(29) //Rx buffer full INT reset
#define IFI_CAN_INTMASK_WR_SBM	((u32)BIT(31)) //Set Buffer Int Mask

/********* CAN Status - Offset 6 *********/
#define IFI_CAN_STATUS			0x18

#define IFI_CAN_STATUS_RD_I_BOFF	BIT(0)  // Busoff State
#define IFI_CAN_STATUS_RD_I_WARN	BIT(1)  // warning state
#define IFI_CAN_STATUS_RD_EACT		BIT(2)  // error active
#define IFI_CAN_STATUS_RD_EPAS		BIT(3)  // error passive
#define IFI_CAN_STATUS_RD_SIL		BIT(4)  // silent mode

#define IFI_CAN_STATUS_RD_I_TOK		BIT(14) // Transmit ok INT
#define IFI_CAN_STATUS_RD_MSG		BIT(15) // Message in Transmit

#define IFI_CAN_STATUS_RD_I_ERR		BIT(16) // Error Exist Int
#define IFI_CAN_STATUS_RD_HPM		BIT(21) // High Priority Msg Active
#define IFI_CAN_STATUS_RD_TBF		BIT(22) // Transmit buffer full
#define IFI_CAN_STATUS_RD_RBF		BIT(23) // Receive buffer full

#define IFI_CAN_STATUS_RD_I_TBE		BIT(24) // Tx buffer empty INT
#define IFI_CAN_STATUS_RD_I_TBO		BIT(25) // Tx buffer overflow INT
#define IFI_CAN_STATUS_RD_I_TBF		BIT(26) // Tx buffer full INT
#define IFI_CAN_STATUS_RD_I_RNE		BIT(27) // Rx buffer not empty INT
#define IFI_CAN_STATUS_RD_I_RBO		BIT(28) // Rx buffer overflow INT
#define IFI_CAN_STATUS_RD_I_RBF		BIT(29) // Rx buffer full INT
#define IFI_CAN_STATUS_RD_TB		BIT(30) // Transmit busy
#define IFI_CAN_STATUS_RD_RB		((u32)BIT(31)) // Receive busy

#define IFI_CAN_STATUS_WR_I_BOFF	BIT(0)  // Busoff INT reset
#define IFI_CAN_STATUS_WR_I_WARN	BIT(1)  // Error warning INT reset
#define IFI_CAN_STATUS_WR_NEXT		BIT(7)  // RecFifo read next value

#define IFI_CAN_STATUS_WR_I_TOK		BIT(14) // Transmit ok INT reset
#define IFI_CAN_STATUS_WR_I_ERR		BIT(16) // Error Exist Int reset

#define IFI_CAN_STATUS_WR_I_TBE		BIT(24) //Tx buffer empty INT reset
#define IFI_CAN_STATUS_WR_I_TBO		BIT(25) //Tx buf overflow INT reset
#define IFI_CAN_STATUS_WR_I_TBF		BIT(26) //Tx buffer full INT reset
#define IFI_CAN_STATUS_WR_I_RNE		BIT(27) //Rx buf not empty INTreset
#define IFI_CAN_STATUS_WR_I_RBO		BIT(28) //Rx buf overflow INT reset
#define IFI_CAN_STATUS_WR_I_RBF		BIT(29) //Rx buffer full INT reset

#define IFI_CAN_STATUS_MASK		(IFI_CAN_STATUS_RD_I_BOFF | \
					IFI_CAN_STATUS_RD_I_WARN | \
					IFI_CAN_STATUS_RD_I_TOK  | \
					IFI_CAN_STATUS_RD_I_ERR  | \
					IFI_CAN_STATUS_RD_I_TBE  | \
					IFI_CAN_STATUS_RD_I_TBO  | \
					IFI_CAN_STATUS_RD_I_TBF  | \
					IFI_CAN_STATUS_RD_I_RNE  | \
					IFI_CAN_STATUS_RD_I_RBO  | \
					IFI_CAN_STATUS_RD_I_RBF)

/********* Error Counter - Offset 7 *********/
#define IFI_CAN_ERROR			0x1C

#define IFI_CAN_ERROR_RD_TE		0x000001FF // Transmit Error Counter
#define IFI_CAN_ERROR_RD_RE		0x00FF0000 // Receive Error Counter

#define IFI_CAN_ERROR_RX_MASK		0xFF
#define IFI_CAN_ERROR_TX_MASK		0x1FF

#define IFI_CAN_ERROR_TX_OFFSET		0
#define IFI_CAN_ERROR_RX_OFFSET		16

/********* Version - Offset 8 *********/
#define IFI_CAN_VERSION			0x20

#define IFI_CAN_VERSION_RD_CR		0x000000FF  // core revision
#define IFI_CAN_VERSION_RD_Q		0x0000FF00  // quartus
#define IFI_CAN_VERSION_RD_Y		0x00FF0000  // year
#define IFI_CAN_VERSION_RD_M		0xFF000000  // month

/********* FIFO Pointer - Offset 9 *********/
#define IFI_CAN_FIFO_PNTR		0x24

#define IFI_CAN_FIFO_PTR_RD_TBC		0x000001FF  // transmit buffer Counter
#define IFI_CAN_FIFO_PTR_RD_RBC		0x1FFF0000  // receive buffer Counter

#define IFI_CAN_FIFO_PTR_WR_RRB		((u32)BIT(31)) // reset receive buffer
#define IFI_CAN_FIFO_PTR_WR_RTB		BIT(15)  // reset transmit Counter

#define IFI_CAN_FIFO_TX_OFF		0
#define IFI_CAN_FIFO_RX_OFF		16

/********* Timestamp Register - Offset 10 *********/
#define IFI_CAN_TIMESTAMP		0x28
/********* Current Timestamp - Offset 11 *********/
#define IFI_CAN_CURTIMESTAMP		0x2C

/********* Parameter Register - Offset 12 *********/
#define IFI_CAN_PARA			0x30

#define IFI_CAN_PARA_RD_TIM		BIT(0)      // timer on off
#define IFI_CAN_PARA_RD_FNO		0x000000F0  // filter number
#define IFI_CAN_PARA_RD_TBS		0x00000F00  // transmit buffer size
#define IFI_CAN_PARA_RD_RBS		0x0000F000  // receive buffer size
#define IFI_CAN_PARA_RD_DBW		0x000F0000  // width
#define IFI_CAN_PARA_RD_M_N		BIT(20)     // Mhz or ns
#define IFI_CAN_PARA_RD_CLK		0xFF000000  // clock
					     //Filters and Masks
#define IFI_CAN_PARA_FNO_VAL8		8    //Filter value  8 =>  64
#define IFI_CAN_PARA_FNO_CONV8		64   //Filter value  8 =>  64
#define IFI_CAN_PARA_FNO_VAL9		9    //Filter value  9 => 128
#define IFI_CAN_PARA_FNO_CONV9		128  //Filter value  9 => 128
#define IFI_CAN_PARA_FNO_VAL10		10   //Filter value 10 => 256
#define IFI_CAN_PARA_FNO_CONV10		256  //Filter value 10 => 256

/********* Error Detail - Offset 13 *********/
#define IFI_CAN_ERRORDETAIL		0x34

#define IFI_RD_ERR_FIRST		0x000000FF // error first
#define IFI_RD_ERR_ALL			0x0000FF00 // error all
#define IFI_RD_BIT_POS			0x00FF0000 // bit position
#define IFI_RD_SSM			BIT(24) // single shot mode enable
#define IFI_RD_ERR_ENA			((u32)BIT(31)) // error register enable

#define IFI_WR_SSM			BIT(24) // single shot mode enable
#define IFI_WR_ERR_RST			BIT(30) // error register reset
#define IFI_WR_ERR_ENA			((u32)BIT(31)) // error register enable

#define IFI_ERR_FIRST_S			0
#define IFI_ERR_ALL_S			8
#define IFI_BIT_POS_S			16

#define IFI_CAN_ERR_OVERLOAD		BIT(0)
#define IFI_CAN_ERR_ACK			BIT(1)
#define IFI_CAN_ERR_BIT0		BIT(2)
#define IFI_CAN_ERR_BIT1		BIT(3)
#define IFI_CAN_ERR_STUFF		BIT(4)
#define IFI_CAN_ERR_CRC			BIT(5)
#define IFI_CAN_ERR_FORM		BIT(6)
#define IFI_CAN_ERR_RES			BIT(7)

/********* Hard Reset Register - Offset 14 *********/
#define IFI_CAN_HARDRESET		0x38

#define IFI_CAN_RST_WR_EN		0xDEADCAFD
#define IFI_CAN_RST_WR_DISABLE		0x00000001

#define IFI_CAN_RD_RESET		0x40000000
#define IFI_NO_HARDRESET		0

/********* Filter Mask - Offset 512 *********/
#define IFI_CAN_FMASK			0x800
#define IFI_CAN_FILTER_MASK(n)		(IFI_CAN_FMASK + ((n) * 8) + 0)

#define IFI_CAN_RD_FMASK		0x1FFFFFFF	// filter mask
#define IFI_CAN_RD_FMEXT		BIT(29)		// extended ?
#define IFI_CAN_RD_FMVALID		((u32)BIT(31))	// valid ?

/********* Filter ID - Offset 513 *********/
#define IFI_CAN_FID			0x804
#define IFI_CAN_FILTER_IDENT(n)		(IFI_CAN_FID + ((n) * 8))

#define IFI_CAN_RD_FID			0x1FFFFFFF	// filter mask
#define IFI_CAN_RD_FIDEXT		BIT(29)		// extended ?
#define IFI_CAN_RD_FIDVALID		((u32)BIT(31))	// valid ?

#define IFI_CAN_CUSTOM_IRQ_HANDLE	0x1      //for custom mode flags

#define IFI_CAN_DEFAULT_RESTART_MS	100

#define IFI_CAN_E_FAILED		0xFFFFFFFF

/* IFI CAN private data structure */
struct ifi_can_priv {
	struct can_priv		can;	/* must be the first member */
	struct napi_struct	napi;
	struct timer_list   tList;	
	struct net_device	*ndev;

	void __iomem		*base;

	void			    *priv;	/* For board-specific data */
	spinlock_t		     recv_lock;
	spinlock_t		     status_lock;
	u16			         flags;	/* custom mode flags*/

	void (*pre_irq)(const struct ifi_can_priv *priv);
	void (*post_irq)(const struct ifi_can_priv *priv);

	void (*chk_irq)(const struct ifi_can_priv *priv);

	// custom flags 
	u32		rxIntStat;

	u64		msgs;
	u32		msg_index;
	
	bool 	loopback;	

	u32		isrCountIn;
	u32		isrCountNapi;
	u32		isrCountNapiAfter;
	u32		isrCountNapiRxNot;
	u32		isrCountNapiTx;
	u32		isrCountOut;

	u32		isrRxMsgTrue;
	u32		isrRxMsgFalse;

	u32		napiCountIn;
	u32		napiCountOut;
	u32		napiCountFinish;
	u32		napiCountFull;

	bool		debugOn;

};

/**
 * ifi_can_isr() - handles interrupts
 * @irq: IRQ line
 * @dev_id: Device ID
 *
 * This function handles interrupts
 *
 * Return: Interrupt Handling Status
 */
irqreturn_t ifi_can_isr(int irq, void *dev_id);

/**
 * ifi_can_irq_enable() - Enable/disable interrupts
 * @ndev: Network device (CAN)
 * @enable: flag 1-enable,0-disable
 * @clear: flag to clear interrupts when set to 1
 *
 * This function enables/disables/clears interrupts on request
 *
 * Return: None
 */
void ifi_can_irq_enable(struct net_device *ndev, bool enable, u8 clear);

/**
 * ifi_can_set_bittiming() - Set CAN bit timings
 * @ndev: Network device (CAN)
 *
 * This function sets CAN bit timings and data bit timings
 *
 * Return: None
 */
void ifi_can_set_bittiming(struct net_device *ndev);

/**
 * ifi_canfd_set_filters() - Set Filter masks and IDs
 * @ndev: Network device (CAN)
 * @enable: enable/disable flag
 *
 * This function sets Filter masks and IDs for Standard and extended CAN frames
 *
 * Return: None
 */
void ifi_can_set_filters(struct net_device *ndev, bool enable);

/**
 * ifi_can_poll() - NAPI polling function
 * @napi:
 * @quota:This parameter places a limit on the amount of work the driver may do
 *         If and only if the return value is less than the budget, your
 *         driver must reenable interrupts and turn off polling
 *
 * This function polls the driver shortly to pick up all available packets
 * when interrupt is being serviced
 *
 * Return: No. of packets processed
 */
int ifi_can_poll(struct napi_struct *napi, int quota);

/**
 * alloc_ifi_can_dev() - Allocate CAN device
 * @sizeof_priv: size of device interface
 * @echo_skb_max: max. number of sockets
 *
 * This function allocates a CAN device
 *
 * Return: Network device allocated
 */
struct net_device *alloc_ifi_can_dev(int sizeof_priv, int echo_skb_max);

/**
 * free_ifi_can_dev() - Free CAN device
 * @ndev: Network device (CAN)
 *
 * This function frees previously allocated CAN device
 *
 * Return: None
 */
void free_ifi_can_dev(struct net_device *ndev);

/**
 * register_ifi_can_dev() - Register CAN device
 * @ndev: Network device (CAN)
 *
 * This function registers CAN device and sets netdev_ops structure
 *
 * Return: return code register_candev
 */
int register_ifi_can_dev(struct net_device *ndev);

/**
 * unregister_ifi_can_dev() - Unregister CAN device
 * @ndev: Network device (CAN)
 *
 * This function unregisters CAN device
 *
 * Return: None
 */
void unregister_ifi_can_dev(struct net_device *ndev);

/**
 * ifi_can_get_IntStatReg() - read ifi can status register
 * @ifi_can_priv: IFI CAN private data structure
 * @fForce: force trace printk output if enabled
 * @szText: additional text for trace printk
 * @pRxInt: ptr on masked Rx Interrupt field
 * @pTxInt: ptr on masked Tx Interrupt field
 * @pOtherInt: ptr on masked Other Interrupt field
 * @pStatusReg: interrupt status register
 *
 * This function reads ifi can status register
 *
 * Return: true if a Rx, Tx or Other interrupt is set ( depends on pRxInt, pTxInt, pOtherInt)
 */
bool ifi_can_get_IntStatReg(struct ifi_can_priv *priv , 
						bool fForce, char * szText,
						u32 * pRxInt, u32 * pTxInt, u32 * pOtherInt, u32 * pIntStatReg );


/**
 * ifi_can_set_IntStatReg() - write to IFI interrupt status register
 * @ifi_can_priv: IFI CAN private data structure
 * @pStatusReg: interrupt status register* 
 * @fForce: force trace printk output if enabled
 * @szText: additional text for trace printk
 *
 * This function writes to IFI interrupt status register
 *
 * Return: None
 */
bool ifi_can_set_IntStatReg (struct ifi_can_priv *priv , const u32 StatusReg, 
						bool fForce, char * szText );

/**
 * ifi_can_get_IntEnaReg() - get the content of the IFI interrupt enable register
 * @ifi_can_priv: IFI CAN private data structure
 * @fForce: force trace printk output if enabled
 * @szText: additional text for trace printk
 * @pRxInt: ptr on masked Rx Interrupt field
 * @pTxInt: ptr on masked Tx Interrupt field
 * @pIntEnaReg: interrupt status register
 *
 * This function gets the content of the IFI interrupt enable register
 *
 * Return: None
 */
bool ifi_can_get_IntEnaReg(struct ifi_can_priv *priv , 
						bool fForce,
						char * szText, 
						u32 * pRxInt, u32 * pTxInt, u32 * pIntEnaReg);

/**
 * unregister_ifi_can_dev() - timer function
 * @data: ptr on the timer_list
 *
 * timer function
 *
 * Return: None
 */
void ifi_can_timer (struct timer_list * data);

#endif /* IFI_CAN_H_ */


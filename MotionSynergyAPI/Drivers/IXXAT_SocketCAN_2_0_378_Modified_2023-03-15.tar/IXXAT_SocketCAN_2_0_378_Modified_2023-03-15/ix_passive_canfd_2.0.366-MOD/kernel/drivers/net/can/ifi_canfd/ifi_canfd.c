// SPDX-License-Identifier: GPL-2.0

/* CAN driver base for IXXAT PCI-to-CAN
 *
 * Copyright (C) 2018 HMS Industrial Networks <socketcan@hms-networks.de>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published
 * by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * General Public License for more details.
 */

#include <linux/clk.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/platform_device.h>
#include <linux/can/dev.h>
#include <linux/version.h>

#include "ifi_canfd.h"

#define IFI_CANFD_TSEG1_MIN 1
#define IFI_CANFD_TSEG1_MAX 256
#define IFI_CANFD_TSEG2_MIN 2
#define IFI_CANFD_TSEG2_MAX 256
#define IFI_CANFD_SJW_MAX 128
#define IFI_CANFD_BRP_MIN 2
#define IFI_CANFD_BRP_MAX 512
#define IFI_CANFD_BRP_INC 1

MODULE_AUTHOR("HMS Technology Center Ravensburg Gmbh <socketcan@hms-networks.de>");
MODULE_DESCRIPTION("driver for IFI CANFD controller");
MODULE_LICENSE("GPL v2");
MODULE_VERSION("1.0.0-rc");

#if KERNEL_VERSION(5, 10, 17) > LINUX_VERSION_CODE
  #define can_fd_dlc2len(dlc) can_dlc2len(get_canfd_dlc(dlc))
  #define can_fd_len2dlc(dlc) can_len2dlc(dlc)

  #define can_cc_dlc2len(dlc) get_can_dlc(dlc)
#endif

#if defined(CONFIG_TRACING) && defined(DEBUG)
	#define ix_trace_printk(...) trace_printk(__VA_ARGS__)
#else
	#define ix_trace_printk(...)
#endif


static const struct can_bittiming_const ifi_canfd_bittiming_const = {
	.name = KBUILD_MODNAME, // IXXAT_PCI_DEV_NAME,
	.tseg1_min	= IFI_CANFD_TSEG1_MIN,
	.tseg1_max	= IFI_CANFD_TSEG1_MAX,
	.tseg2_min	= IFI_CANFD_TSEG2_MIN,
	.tseg2_max	= IFI_CANFD_TSEG2_MAX,
	.sjw_max	= IFI_CANFD_SJW_MAX,
	.brp_min	= IFI_CANFD_BRP_MIN,
	.brp_max	= IFI_CANFD_BRP_MAX,
	.brp_inc	= IFI_CANFD_BRP_INC,
};

static u32 ifi_canfd_msg_get_next_idx(struct net_device *netdev)
{
	struct ifi_canfd_priv *priv = netdev_priv(netdev);
	u32 MsgIdx	= 0;
	u32 LoopCnt = 0;
	u64 Mask;

	MsgIdx = (priv->msg_index + 1) % priv->can.echo_skb_max;
	while (LoopCnt < priv->can.echo_skb_max) {
		Mask = (1 << MsgIdx);

		if ((priv->msgs & Mask) == 0) {
			priv->msgs |= Mask;
			break;
		}

		MsgIdx = (MsgIdx + 1) % priv->can.echo_skb_max;
		LoopCnt++;
	}

	if (LoopCnt < priv->can.echo_skb_max) {
		priv->msg_index = MsgIdx;
		return MsgIdx;
	} else
		return IFI_CANFD_E_FAILED;
}

static void ifi_canfd_msg_free_idx(struct net_device *netdev, u32 MsgIdx)
{
	struct ifi_canfd_priv *priv = netdev_priv(netdev);
	u64 Mask;

	if (MsgIdx == 0xFFFFFFFF) {
		priv->msgs = 0;
		priv->msg_index = 0;
	} else if (MsgIdx < priv->can.echo_skb_max) {
		Mask = (1 << MsgIdx);
		priv->msgs &= ~Mask;
	}
}


static int ifi_canfd_get_berr_counter(const struct net_device *ndev,
							struct can_berr_counter *bec)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	u32 err;

	err = readl(priv->base + IFI_CANFD_ERROR);
	bec->rxerr = (err >> IFI_CANFD_ERROR_RX_OFFSET) &
		IFI_CANFD_ERROR_RX_MASK;
	bec->txerr = (err >> IFI_CANFD_ERROR_TX_OFFSET) &
		IFI_CANFD_ERROR_TX_MASK;

	return 0;
}

static int ifi_canfd_handle_lost_msg(struct net_device *ndev)
{
	struct net_device_stats *stats = &ndev->stats;
	struct sk_buff *skb;
	struct can_frame *frame;

	netdev_err(ndev, "RX FIFO overflow, message(s) lost.\n");

	stats->rx_errors++;
	stats->rx_over_errors++;

	skb = alloc_can_err_skb(ndev, &frame);
	if (unlikely(!skb))
		return 0;

	frame->can_id |= CAN_ERR_CRTL;
	frame->data[1] = CAN_ERR_CRTL_RX_OVERFLOW;

	netif_receive_skb(skb);

	return 1;
}

static int ifi_canfd_handle_lec_err(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	struct net_device_stats *stats = &ndev->stats;
	struct can_frame *cf;
	struct sk_buff *skb;
	u32 errctr = readl(priv->base + IFI_CANFD_ERROR_CTR);
	const u32 errmask = IFI_CANFD_ERROR_CTR_OVERLOAD_FIRST |
		IFI_CANFD_ERROR_CTR_ACK_ERROR_FIRST |
		IFI_CANFD_ERROR_CTR_BIT0_ERROR_FIRST |
		IFI_CANFD_ERROR_CTR_BIT1_ERROR_FIRST |
		IFI_CANFD_ERROR_CTR_STUFF_ERROR_FIRST |
		IFI_CANFD_ERROR_CTR_CRC_ERROR_FIRST |
		IFI_CANFD_ERROR_CTR_FORM_ERROR_FIRST;

	if (!(errctr & errmask))	/* No error happened. */
		return 0;

	priv->can.can_stats.bus_error++;
	stats->rx_errors++;

	/* Propagate the error condition to the CAN stack. */
	skb = alloc_can_err_skb(ndev, &cf);
	if (unlikely(!skb))
		return 0;

	/* Read the error counter register and check for new errors. */
	cf->can_id |= CAN_ERR_PROT | CAN_ERR_BUSERROR;

	if (errctr & IFI_CANFD_ERROR_CTR_OVERLOAD_FIRST)
		cf->data[2] |= CAN_ERR_PROT_OVERLOAD;

	if (errctr & IFI_CANFD_ERROR_CTR_ACK_ERROR_FIRST)
		cf->data[3] = CAN_ERR_PROT_LOC_ACK;

	if (errctr & IFI_CANFD_ERROR_CTR_BIT0_ERROR_FIRST)
		cf->data[2] |= CAN_ERR_PROT_BIT0;

	if (errctr & IFI_CANFD_ERROR_CTR_BIT1_ERROR_FIRST)
		cf->data[2] |= CAN_ERR_PROT_BIT1;

	if (errctr & IFI_CANFD_ERROR_CTR_STUFF_ERROR_FIRST)
		cf->data[2] |= CAN_ERR_PROT_STUFF;

	if (errctr & IFI_CANFD_ERROR_CTR_CRC_ERROR_FIRST)
		cf->data[3] = CAN_ERR_PROT_LOC_CRC_SEQ;

	if (errctr & IFI_CANFD_ERROR_CTR_FORM_ERROR_FIRST)
		cf->data[2] |= CAN_ERR_PROT_FORM;

	/* Reset the error counter, ack the IRQ and re-enable the counter. */
	writel(IFI_CANFD_ERROR_CTR_ER_RESET,
				 priv->base + IFI_CANFD_ERROR_CTR);
	writel(IFI_CANFD_INTERRUPT_ERROR_COUNTER,
				 priv->base + IFI_CANFD_INTERRUPT);
	writel(IFI_CANFD_ERROR_CTR_ER_ENABLE,
				 priv->base + IFI_CANFD_ERROR_CTR);

	stats->rx_packets++;
	stats->rx_bytes += cf->can_dlc;
	netif_receive_skb(skb);

	return 1;
}

static int ifi_canfd_handle_state_change(struct net_device *ndev,
					 enum can_state new_state)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	struct net_device_stats *stats = &ndev->stats;
	struct can_frame *cf;
	struct sk_buff *skb;
	struct can_berr_counter bec;

	switch (new_state) {
	case CAN_STATE_ERROR_ACTIVE:
		/* error active state */
		priv->can.can_stats.error_warning++;
		priv->can.state = CAN_STATE_ERROR_ACTIVE;
		break;
	case CAN_STATE_ERROR_WARNING:
		/* error warning state */
		priv->can.can_stats.error_warning++;
		priv->can.state = CAN_STATE_ERROR_WARNING;
		break;
	case CAN_STATE_ERROR_PASSIVE:
		/* error passive state */
		priv->can.can_stats.error_passive++;
		priv->can.state = CAN_STATE_ERROR_PASSIVE;
		break;
	case CAN_STATE_BUS_OFF:
		/* bus-off state */
		priv->can.state = CAN_STATE_BUS_OFF;
		ifi_canfd_irq_enable(ndev, 0, 0);
		priv->can.can_stats.bus_off++;
		can_bus_off(ndev);
		break;
	default:
		break;
	}

	/* propagate the error condition to the CAN stack */
	skb = alloc_can_err_skb(ndev, &cf);
	if (unlikely(!skb))
		return 0;

	ifi_canfd_get_berr_counter(ndev, &bec);

	switch (new_state) {
	case CAN_STATE_ERROR_WARNING:
		/* error warning state */
		cf->can_id |= CAN_ERR_CRTL;
		cf->data[1] = (bec.txerr > bec.rxerr) ?
			CAN_ERR_CRTL_TX_WARNING :
			CAN_ERR_CRTL_RX_WARNING;
		cf->data[6] = bec.txerr;
		cf->data[7] = bec.rxerr;
		break;
	case CAN_STATE_ERROR_PASSIVE:
		/* error passive state */
		cf->can_id |= CAN_ERR_CRTL;
		cf->data[1] |= CAN_ERR_CRTL_RX_PASSIVE;
		if (bec.txerr > 127)
			cf->data[1] |= CAN_ERR_CRTL_TX_PASSIVE;
		cf->data[6] = bec.txerr;
		cf->data[7] = bec.rxerr;
		break;
	case CAN_STATE_BUS_OFF:
		/* bus-off state */
		cf->can_id |= CAN_ERR_BUSOFF;
		break;
	default:
		break;
	}

	stats->rx_packets++;
	stats->rx_bytes += cf->can_dlc;
	netif_receive_skb(skb);

	return 1;
}

static int ifi_canfd_handle_error_status(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	u32 stcmd = readl(priv->base + IFI_CANFD_STCMD);
	int work_done = 0;

	if ((stcmd & IFI_CANFD_STCMD_ERROR_ACTIVE) &&
			priv->can.state != CAN_STATE_ERROR_ACTIVE) {
		netdev_dbg(ndev, "Error, entered active state\n");
		work_done += ifi_canfd_handle_state_change(ndev,
			CAN_STATE_ERROR_ACTIVE);
	}

	if ((stcmd & IFI_CANFD_STCMD_ERROR_WARNING) &&
			priv->can.state != CAN_STATE_ERROR_WARNING) {
		netdev_dbg(ndev, "Error, entered warning state\n");
		work_done += ifi_canfd_handle_state_change(ndev,
			CAN_STATE_ERROR_WARNING);
	}

	if ((stcmd & IFI_CANFD_STCMD_ERROR_PASSIVE) &&
			priv->can.state != CAN_STATE_ERROR_PASSIVE) {
		netdev_dbg(ndev, "Error, entered passive state\n");
		work_done += ifi_canfd_handle_state_change(ndev,
			CAN_STATE_ERROR_PASSIVE);
	}

	if ((stcmd & IFI_CANFD_STCMD_BUSOFF) &&
			priv->can.state != CAN_STATE_BUS_OFF) {
		netdev_dbg(ndev, "Error, entered bus-off state\n");
		work_done += ifi_canfd_handle_state_change(ndev,
						CAN_STATE_BUS_OFF);
	}

	return work_done;
}

static void ifi_canfd_read_fifo(struct net_device *ndev)
{
	struct net_device_stats *stats = &ndev->stats;
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	struct canfd_frame *cf;
	struct sk_buff *skb;
	const u32 rx_irq_mask = IFI_CANFD_INTERRUPT_RXFIFO_NEMPTY |
				IFI_CANFD_INTERRUPT_RXFIFO_NEMPTY_PER;
	u32 rxdlc, rxid;
	u32 dlc, id, frn, len, ret;
	int i;

	rxdlc = readl(priv->base + IFI_CANFD_RXFIFO_DLC);
	frn = (rxdlc & IFI_CANFD_RXFIFO_DLC_FNR_MASK) >> IFI_CANFD_RXFIFO_DLC_FNR_OFFSET;
	dlc = (rxdlc >> IFI_CANFD_RXFIFO_DLC_DLC_OFFSET) &
		IFI_CANFD_RXFIFO_DLC_DLC_MASK;
		
	if (rxdlc & IFI_CANFD_RXFIFO_DLC_EDL)
		len = can_fd_dlc2len(dlc);
	else
		len = can_cc_dlc2len(dlc);			
		
	if (frn) {
		ret = ixx_can_get_echo_skb(ndev, frn);

		if (ret)
			stats->tx_bytes += ret;
		else
			stats->tx_bytes += len;

		stats->tx_packets++;
		ifi_canfd_msg_free_idx(ndev, frn);
	} else {
	
		if (rxdlc & IFI_CANFD_RXFIFO_DLC_EDL)
			skb = alloc_canfd_skb(ndev, &cf);
		else
			skb = alloc_can_skb(ndev, (struct can_frame **)&cf);

		if (!skb) {
			stats->rx_dropped++;
			return;
		}

		cf->len = len;

		rxid = readl(priv->base + IFI_CANFD_RXFIFO_ID);
		id = (rxid >> IFI_CANFD_RXFIFO_ID_ID_OFFSET);
		if (id & IFI_CANFD_RXFIFO_ID_IDE) {
			id &= IFI_CANFD_RXFIFO_ID_ID_XTD_MASK;
			/* In case the Extended ID frame is received, the standard
			 * and extended part of the ID are swapped in the register,
			 * so swap them back to obtain the correct ID.
			 */
			id = (id >> IFI_CANFD_RXFIFO_ID_ID_XTD_OFFSET) |
				((id & IFI_CANFD_RXFIFO_ID_ID_STD_MASK) <<
				IFI_CANFD_RXFIFO_ID_ID_XTD_WIDTH);
			id |= CAN_EFF_FLAG;
		} else {
			id &= IFI_CANFD_RXFIFO_ID_ID_STD_MASK;
		}
		cf->can_id = id;

		if (rxdlc & IFI_CANFD_RXFIFO_DLC_ESI) {
			cf->flags |= CANFD_ESI;
			netdev_dbg(ndev, "ESI Error\n");
		}

		if (!(rxdlc & IFI_CANFD_RXFIFO_DLC_EDL) &&
				(rxdlc & IFI_CANFD_RXFIFO_DLC_RTR)) {
			cf->can_id |= CAN_RTR_FLAG;
		} else {
			if (rxdlc & IFI_CANFD_RXFIFO_DLC_BRS)
				cf->flags |= CANFD_BRS;

			for (i = 0; i < cf->len; i += 4) {
				*(u32 *)(cf->data + i) =
					readl(priv->base + IFI_CANFD_RXFIFO_DATA + i);
			}
		}

		stats->rx_packets++;
		stats->rx_bytes += cf->len;

		netif_receive_skb(skb);
	}
	
	/* Remove the packet from FIFO */
	writel(IFI_CANFD_RXSTCMD_REMOVE_MSG, priv->base + IFI_CANFD_RXSTCMD);
	writel(rx_irq_mask, priv->base + IFI_CANFD_INTERRUPT);
}

static int ifi_canfd_do_rx_poll(struct net_device *ndev, int quota)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	u32 pkts = 0;
	u32 rxst;

	rxst = readl(priv->base + IFI_CANFD_RXSTCMD);
	if (rxst & IFI_CANFD_RXSTCMD_EMPTY) {
		netdev_dbg(ndev, "No messages in RX FIFO\n");
		return 0;
	}

	for (;;) {
		if (rxst & IFI_CANFD_RXSTCMD_EMPTY)
			break;
		if (quota <= 0)
			break;

		ifi_canfd_read_fifo(ndev);
		quota--;
		pkts++;
		rxst = readl(priv->base + IFI_CANFD_RXSTCMD);
	}

	if (pkts)
		can_led_event(ndev, CAN_LED_EVENT_RX);

	return pkts;
}

int ifi_canfd_poll(struct napi_struct *napi, int quota)
{
	struct net_device *ndev = napi->dev;
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	u32 rxstcmd = readl(priv->base + IFI_CANFD_RXSTCMD);
	int work_done = 0;

	/* Handle bus state changes */
	work_done += ifi_canfd_handle_error_status(ndev);

	/* Handle lost messages on RX */
	if (rxstcmd & IFI_CANFD_RXSTCMD_OVERFLOW)
		work_done += ifi_canfd_handle_lost_msg(ndev);

	/* Handle lec errors on the bus */
	if (priv->can.ctrlmode & CAN_CTRLMODE_BERR_REPORTING)
		work_done += ifi_canfd_handle_lec_err(ndev);

	/* Handle normal messages on RX */
	if (!(rxstcmd & IFI_CANFD_RXSTCMD_EMPTY))
		work_done += ifi_canfd_do_rx_poll(ndev, quota - work_done);

	if (work_done < quota) {
		napi_complete_done(napi, work_done);
		ifi_canfd_irq_enable(ndev, 1, 0);
	}

	return work_done;
}
EXPORT_SYMBOL_GPL(ifi_canfd_poll);

static void ifi_canfd_set_filter(struct net_device *ndev, const u32 id,
				 bool enable, u32 mask, u32 ident)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);

	if (!enable) {
		mask = 0;
		ident = 0;
	}

	writel(mask, priv->base + IFI_CANFD_FILTER_MASK(id));
	writel(ident, priv->base + IFI_CANFD_FILTER_IDENT(id));
}

void ifi_canfd_set_filters(struct net_device *ndev, bool enable)
{
	/* Receive all CAN frames (standard ID) */
	ifi_canfd_set_filter(ndev, 0, enable,
					 IFI_CANFD_FILTER_MASK_VALID |
					 IFI_CANFD_FILTER_MASK_EXT,
					 IFI_CANFD_FILTER_IDENT_VALID);

	/* Receive all CAN frames (extended ID) */
	ifi_canfd_set_filter(ndev, 1, enable,
					 IFI_CANFD_FILTER_MASK_VALID |
					 IFI_CANFD_FILTER_MASK_EXT,
					 IFI_CANFD_FILTER_IDENT_VALID |
					 IFI_CANFD_FILTER_IDENT_IDE);

	/* Receive all CANFD frames */
	ifi_canfd_set_filter(ndev, 2, enable,
					 IFI_CANFD_FILTER_MASK_VALID |
					 IFI_CANFD_FILTER_MASK_EDL |
					 IFI_CANFD_FILTER_MASK_EXT,
					 IFI_CANFD_FILTER_IDENT_VALID |
					 IFI_CANFD_FILTER_IDENT_CANFD |
					 IFI_CANFD_FILTER_IDENT_IDE);
}
EXPORT_SYMBOL_GPL(ifi_canfd_set_filters);

static void ifi_canfd_irq_clear(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	u32 ifi_reg_status = readl(priv->base + IFI_CANFD_INTERRUPT);

	/* Clear pending IFI CAN controller interrupts */
	writel(ifi_reg_status, priv->base + IFI_CANFD_INTERRUPT);

	/* Unlock, reset and enable the error counter. */
	writel(IFI_CANFD_ERROR_CTR_UNLOCK_MAGIC,
				 priv->base + IFI_CANFD_ERROR_CTR);
	writel(IFI_CANFD_ERROR_CTR_ER_RESET, priv->base + IFI_CANFD_ERROR_CTR);
	writel(IFI_CANFD_ERROR_CTR_ER_ENABLE, priv->base + IFI_CANFD_ERROR_CTR);
}

void ifi_canfd_irq_enable(struct net_device *ndev, bool enable, u8 clear)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	u32 enirq = 0;

	if (enable) {
		enirq = IFI_CANFD_IRQMASK_TXFIFO_EMPTY |
			IFI_CANFD_IRQMASK_RXFIFO_NEMPTY |
			IFI_CANFD_IRQMASK_ERROR_STATE_CHG |
			IFI_CANFD_IRQMASK_ERROR_WARNING |
			IFI_CANFD_IRQMASK_ERROR_BUSOFF;
		if (priv->can.ctrlmode & CAN_CTRLMODE_BERR_REPORTING)
			enirq |= IFI_CANFD_INTERRUPT_ERROR_COUNTER;
	}

	writel(IFI_CANFD_IRQMASK_SET_ERR |
		IFI_CANFD_IRQMASK_SET_TS |
		IFI_CANFD_IRQMASK_SET_TX |
		IFI_CANFD_IRQMASK_SET_RX | enirq,
		priv->base + IFI_CANFD_IRQMASK);

	if (clear)
		ifi_canfd_irq_clear(ndev);
}
EXPORT_SYMBOL_GPL(ifi_canfd_irq_enable);

irqreturn_t ifi_canfd_isr(int irq, void *dev_id)
{
	irqreturn_t iRet = IRQ_NONE;
	struct net_device *ndev = (struct net_device *)dev_id;
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	const u32 rx_irq_mask = IFI_CANFD_INTERRUPT_RXFIFO_NEMPTY |
		IFI_CANFD_INTERRUPT_RXFIFO_NEMPTY_PER |
		IFI_CANFD_INTERRUPT_ERROR_COUNTER |
		IFI_CANFD_INTERRUPT_ERROR_STATE_CHG |
		IFI_CANFD_INTERRUPT_ERROR_WARNING |
		IFI_CANFD_INTERRUPT_ERROR_BUSOFF;
	const u32 tx_irq_mask = IFI_CANFD_INTERRUPT_TXFIFO_EMPTY |
		IFI_CANFD_INTERRUPT_TXFIFO_REMOVE;
	const u32 clr_irq_mask = ~((u32)IFI_CANFD_INTERRUPT_SET_IRQ);
	u32 isr;
	bool fHandled = false;;

	ix_trace_printk (">> ifi_canfd_isr irq %i can %i (%p) \n", irq, ndev->dev_id, dev_id);

	if (priv->pre_irq)
		priv->pre_irq(priv);

	isr = readl(priv->base + IFI_CANFD_INTERRUPT);
	if (isr ) {
		
		/* RX IRQ or bus warning, start NAPI */
		if (isr & rx_irq_mask) {
			ifi_canfd_irq_enable(ndev, 0, 0);
			napi_schedule(&priv->napi);
			fHandled = true;
		}

		if (isr & tx_irq_mask) {
			/* TX IRQ */
			if (isr & IFI_CANFD_INTERRUPT_TXFIFO_REMOVE) {
				can_led_event(ndev, CAN_LED_EVENT_TX);
			}

			netif_wake_queue(ndev);
			fHandled = true;
		}

		if ( fHandled) {
			/* Clear all pending interrupts but ErrWarn */
			writel(clr_irq_mask, priv->base + IFI_CANFD_INTERRUPT);
			iRet = IRQ_HANDLED;
		}
	}

	if (priv->post_irq) {
		priv->post_irq( priv);
	}

	ix_trace_printk ("<< ifi_can_isr irq (isr %x) \n", isr);
	return iRet;
}
EXPORT_SYMBOL_GPL(ifi_canfd_isr);

void ifi_canfd_set_bittiming(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	const struct can_bittiming *bt = &priv->can.bittiming;
	const struct can_bittiming *dbt = &priv->can.data_bittiming;
	u16 brp, sjw, tseg1, tseg2, tdc;

	/* Configure bit timing */
	brp = bt->brp - 2;
	sjw = bt->sjw - 1;
	tseg1 = bt->prop_seg + bt->phase_seg1 - 1;
	tseg2 = bt->phase_seg2 - 2;
	writel((tseg2 << IFI_CANFD_TIME_TIMEB_OFF) |
		(tseg1 << IFI_CANFD_TIME_TIMEA_OFF) |
		(brp << IFI_CANFD_TIME_PRESCALE_OFF) |
		(sjw << IFI_CANFD_TIME_SJW_OFF_7_9_8_8),
		priv->base + IFI_CANFD_TIME);

	/* Configure data bit timing */
	brp = dbt->brp - 2;
	sjw = dbt->sjw - 1;
	tseg1 = dbt->prop_seg + dbt->phase_seg1 - 1;
	tseg2 = dbt->phase_seg2 - 2;
	writel((tseg2 << IFI_CANFD_TIME_TIMEB_OFF) |
		(tseg1 << IFI_CANFD_TIME_TIMEA_OFF) |
		(brp << IFI_CANFD_TIME_PRESCALE_OFF) |
		(sjw << IFI_CANFD_TIME_SJW_OFF_7_9_8_8),
		priv->base + IFI_CANFD_FTIME);

	/* Configure transmitter delay */
	tdc = dbt->brp * (dbt->prop_seg + dbt->phase_seg1);
	tdc &= IFI_CANFD_TDELAY_MASK;
	writel(IFI_CANFD_TDELAY_EN | tdc, priv->base + IFI_CANFD_TDELAY);
}

static void ifi_canfd_start(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	u32 stcmd;

	/* Reset the IP */
	writel(IFI_CANFD_STCMD_HARDRESET, priv->base + IFI_CANFD_STCMD);
	writel(IFI_CANFD_STCMD_ENABLE_7_9_8_8_TIMING,
				 priv->base + IFI_CANFD_STCMD);

	ifi_canfd_set_bittiming(ndev);
	ifi_canfd_set_filters(ndev, 1);

	/* Reset FIFOs */
	writel(IFI_CANFD_RXSTCMD_RESET, priv->base + IFI_CANFD_RXSTCMD);
	writel(0, priv->base + IFI_CANFD_RXSTCMD);
	writel(IFI_CANFD_TXSTCMD_RESET, priv->base + IFI_CANFD_TXSTCMD);
	writel(0, priv->base + IFI_CANFD_TXSTCMD);

	/* Repeat transmission until successful */
	writel(0, priv->base + IFI_CANFD_REPEAT);
	writel(0, priv->base + IFI_CANFD_SUSPEND);

	/* Clear all pending interrupts */
	writel((u32)(~IFI_CANFD_INTERRUPT_SET_IRQ),
				 priv->base + IFI_CANFD_INTERRUPT);

	stcmd = IFI_CANFD_STCMD_ENABLE | IFI_CANFD_STCMD_NORMAL_MODE |
		IFI_CANFD_STCMD_ENABLE_7_9_8_8_TIMING;

	if (priv->can.ctrlmode & CAN_CTRLMODE_LISTENONLY)
		stcmd |= IFI_CANFD_STCMD_BUSMONITOR;

	if (priv->can.ctrlmode & CAN_CTRLMODE_LOOPBACK)
		stcmd |= IFI_CANFD_STCMD_LOOPBACK;

	if ((priv->can.ctrlmode & CAN_CTRLMODE_FD) &&
			!(priv->can.ctrlmode & CAN_CTRLMODE_FD_NON_ISO))
		stcmd |= IFI_CANFD_STCMD_ENABLE_ISO;

	if (!(priv->can.ctrlmode & CAN_CTRLMODE_FD))
		stcmd |= IFI_CANFD_STCMD_DISABLE_CANFD;

	priv->can.state = CAN_STATE_ERROR_ACTIVE;

	ifi_canfd_irq_enable(ndev, 1, 1);

	/* Enable controller */
	writel(stcmd, priv->base + IFI_CANFD_STCMD);
}

static void ifi_canfd_stop(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);

	/* Reset and disable the error counter. */
	writel(IFI_CANFD_ERROR_CTR_ER_RESET, priv->base + IFI_CANFD_ERROR_CTR);
	writel(0, priv->base + IFI_CANFD_ERROR_CTR);

	/* Reset the IP */
	writel(IFI_CANFD_STCMD_HARDRESET, priv->base + IFI_CANFD_STCMD);

	/* Mask all interrupts */
	writel(~0, priv->base + IFI_CANFD_IRQMASK);

	/* Clear all pending interrupts */
	writel((u32)(~IFI_CANFD_INTERRUPT_SET_IRQ),
				 priv->base + IFI_CANFD_INTERRUPT);

	/* Set the state as STOPPED */
	priv->can.state = CAN_STATE_STOPPED;
}

static void ifi_canfd_restart(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	int i;

	ifi_canfd_stop(ndev);

	for (i = 0; i < priv->can.echo_skb_max; ++i)
		ixx_can_free_echo_skb(priv->ndev, i);

	ifi_canfd_msg_free_idx(priv->ndev, 0xFFFFFFFF);

	ifi_canfd_start(ndev);
	netif_wake_queue(priv->ndev);
}

static int ifi_canfd_set_mode(struct net_device *ndev, enum can_mode mode)
{
	switch (mode) {
	case CAN_MODE_START:
		ifi_canfd_restart(ndev);
		break;
	default:
		return -EOPNOTSUPP;
	}

	return 0;
}

struct net_device *alloc_ifi_canfd_dev(int sizeof_priv, int echo_skb_max)
{
	struct net_device *ndev;
	struct ifi_canfd_priv *priv;

	if (echo_skb_max > 64)
		echo_skb_max = 64;

	ndev = alloc_candev(sizeof(struct ifi_canfd_priv) + sizeof_priv,
					echo_skb_max);
	if (!ndev)
		return NULL;

	priv = netdev_priv(ndev);
	priv->ndev = ndev;

	priv->can.bittiming_const	= &ifi_canfd_bittiming_const;
	priv->can.data_bittiming_const	= &ifi_canfd_bittiming_const;
	priv->can.do_set_mode		= ifi_canfd_set_mode;
	priv->can.do_get_berr_counter	= ifi_canfd_get_berr_counter;
	priv->can.restart_ms	= IFI_CANFD_DEFAULT_RESTART_MS;

	/* IFI CANFD can do both Bosch FD and ISO FD */
//	priv->can.ctrlmode = CAN_CTRLMODE_FD;

	/* IFI CANFD can do both Bosch FD and ISO FD */
	priv->can.ctrlmode_supported = CAN_CTRLMODE_LOOPBACK |
		CAN_CTRLMODE_LISTENONLY |
		CAN_CTRLMODE_FD |
		CAN_CTRLMODE_FD_NON_ISO |
		CAN_CTRLMODE_BERR_REPORTING;

	ifi_canfd_msg_free_idx(ndev, 0xFFFFFFFF);

	return ndev;
}
EXPORT_SYMBOL_GPL(alloc_ifi_canfd_dev);

void free_ifi_canfd_dev(struct net_device *ndev)
{
	free_candev(ndev);
}
EXPORT_SYMBOL_GPL(free_ifi_canfd_dev);

static int ifi_canfd_open(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	int ret = open_candev(ndev);

	if (ret)
		return ret;

	/* Register interrupt handler */
	if (!(priv->flags & IFI_CANFD_CUSTOM_IRQ_HANDLING)) {
		ret = request_irq(ndev->irq, ifi_canfd_isr, IRQF_SHARED,
					ndev->name, ndev);
		if (ret < 0) {
			netdev_err(ndev,
					 "Failed to request interrupt: %i\n", ret);
			goto err_irq;
		}
	}

	ifi_canfd_start(ndev);

	can_led_event(ndev, CAN_LED_EVENT_OPEN);
	napi_enable(&priv->napi);
	netif_start_queue(ndev);

	return 0;
err_irq:
	close_candev(ndev);
	return ret;
}

static int ifi_canfd_close(struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);

	netif_stop_queue(ndev);
	napi_disable(&priv->napi);

	ifi_canfd_stop(ndev);

	if (!(priv->flags & IFI_CANFD_CUSTOM_IRQ_HANDLING))
		free_irq(ndev->irq, ndev);

	close_candev(ndev);

	can_led_event(ndev, CAN_LED_EVENT_STOP);

	return 0;
}

static netdev_tx_t ifi_canfd_start_xmit(struct sk_buff *skb,
					struct net_device *ndev)
{
	struct ifi_canfd_priv *priv = netdev_priv(ndev);
	struct canfd_frame *cf = (struct canfd_frame *)skb->data;
	u32 txst, txid, txdlc;
	u32 mask;
	int i;
	u32 MsgIdx;

	if (can_dropped_invalid_skb(ndev, skb))
		return NETDEV_TX_OK;

	/* Check if the TX buffer is full */
	txst = readl(priv->base + IFI_CANFD_TXSTCMD);
	if (txst & IFI_CANFD_TXSTCMD_FULL) {
		netif_stop_queue(ndev);
		netdev_err(ndev, "BUG! TX FIFO full when queue awake!\n");
		return NETDEV_TX_BUSY;
	}

	MsgIdx = ifi_canfd_msg_get_next_idx(ndev);

	if (MsgIdx == IFI_CANFD_E_FAILED)
		return NETDEV_TX_BUSY;

	if (cf->can_id & CAN_EFF_FLAG) {
		txid = cf->can_id & CAN_EFF_MASK;
		/* In case the Extended ID frame is transmitted, the
		 * standard and extended part of the ID are swapped
		 * in the register, so swap them back to send the
		 * correct ID.
		 */
		txid = (txid >> IFI_CANFD_TXFIFO_ID_ID_XTD_WIDTH) |
			((txid & IFI_CANFD_TXFIFO_ID_ID_XTD_MASK) <<
			IFI_CANFD_TXFIFO_ID_ID_XTD_OFFSET);
		txid |= IFI_CANFD_TXFIFO_ID_IDE;
	} else {
		txid = cf->can_id & CAN_SFF_MASK;
	}

	txdlc = can_fd_len2dlc(cf->len);
	if ((priv->can.ctrlmode & CAN_CTRLMODE_FD) && can_is_canfd_skb(skb)) {
		txdlc |= IFI_CANFD_TXFIFO_DLC_EDL;
		if (cf->flags & CANFD_BRS)
			txdlc |= IFI_CANFD_TXFIFO_DLC_BRS;
	}

	if (cf->can_id & CAN_RTR_FLAG)
		txdlc |= IFI_CANFD_TXFIFO_DLC_RTR;

	mask = IFI_CANFD_TXFIFO_DLC_FNR_MASK;
	txdlc &= ~(mask << IFI_CANFD_TXFIFO_DLC_FNR_OFFSET);
	txdlc |= (MsgIdx << IFI_CANFD_TXFIFO_DLC_FNR_OFFSET);

	/* message ram configuration */
	writel(txid, priv->base + IFI_CANFD_TXFIFO_ID);
	writel(txdlc, priv->base + IFI_CANFD_TXFIFO_DLC);

	for (i = 0; i < cf->len; i += 4) {
		writel(*(u32 *)(cf->data + i),
					 priv->base + IFI_CANFD_TXFIFO_DATA + i);
	}

	if (priv->can.ctrlmode & CAN_CTRLMODE_ONE_SHOT)
		writel(1, priv->base + IFI_CANFD_TXFIFO_REPEATCOUNT);
	else
		writel(0, priv->base + IFI_CANFD_TXFIFO_REPEATCOUNT);

	writel(0, priv->base + IFI_CANFD_TXFIFO_SUSPEND_US);

	// PACKET_LOOPBACK flag is checked in the function can_put_
	ixx_can_put_echo_skb(skb, ndev, MsgIdx);

	/* Start the transmission */
	writel(IFI_CANFD_TXSTCMD_ADD_MSG, priv->base + IFI_CANFD_TXSTCMD);

	return NETDEV_TX_OK;
}

static const struct net_device_ops ifi_canfd_netdev_ops = {
	.ndo_open	= ifi_canfd_open,
	.ndo_stop	= ifi_canfd_close,
	.ndo_start_xmit	= ifi_canfd_start_xmit,
	.ndo_change_mtu	= can_change_mtu,
};

int register_ifi_canfd_dev(struct net_device *ndev)
{
	int ret;

	ndev->netdev_ops = &ifi_canfd_netdev_ops;
	ndev->flags |= IFF_ECHO;

	ret =	 register_candev(ndev);
	if (!ret)
		devm_can_led_init(ndev);

	return ret;
}
EXPORT_SYMBOL_GPL(register_ifi_canfd_dev);

void unregister_ifi_canfd_dev(struct net_device *ndev)
{
	unregister_candev(ndev);
}
EXPORT_SYMBOL_GPL(unregister_ifi_canfd_dev);

/* SPDX-License-Identifier: GPL-2.0 */

/* CAN driver base for IXXAT PCI-to-CAN
 *
 * Copyright (C) 2018 HMS Industrial Networks <socketcan@hms-networks.de>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published
 * by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 */

#ifndef IFIFD_PATCH_IFI_CANFD_H_
#define IFIFD_PATCH_IFI_CANFD_H_


#include "../../../../../../common/ixxat_functions.h"

#define IFI_CANFD_STCMD				0x0
#define IFI_CANFD_STCMD_HARDRESET		0xDEADCAFD
#define IFI_CANFD_STCMD_ENABLE			BIT(0)
#define IFI_CANFD_STCMD_ERROR_ACTIVE		BIT(2)
#define IFI_CANFD_STCMD_ERROR_PASSIVE		BIT(3)
#define IFI_CANFD_STCMD_BUSOFF			BIT(4)
#define IFI_CANFD_STCMD_ERROR_WARNING		BIT(5)
#define IFI_CANFD_STCMD_BUSMONITOR		BIT(16)
#define IFI_CANFD_STCMD_LOOPBACK		BIT(18)
#define IFI_CANFD_STCMD_DISABLE_CANFD		BIT(24)
#define IFI_CANFD_STCMD_ENABLE_ISO		BIT(25)
#define IFI_CANFD_STCMD_ENABLE_7_9_8_8_TIMING	BIT(26)
#define IFI_CANFD_STCMD_NORMAL_MODE		((u32)BIT(31))

#define IFI_CANFD_RXSTCMD			0x4
#define IFI_CANFD_RXSTCMD_REMOVE_MSG		BIT(0)
#define IFI_CANFD_RXSTCMD_RESET			BIT(7)
#define IFI_CANFD_RXSTCMD_EMPTY			BIT(8)
#define IFI_CANFD_RXSTCMD_OVERFLOW		BIT(13)
#define IFI_CANFD_RXSTCMD_FIFO_NUMBER		0xFFFF0000
#define IFI_CANFD_RXSTCMD_FIFO_NUMBER_OFF	16

#define IFI_CANFD_TXSTCMD			0x8
#define IFI_CANFD_TXSTCMD_ADD_MSG		BIT(0)
#define IFI_CANFD_TXSTCMD_HIGH_PRIO		BIT(1)
#define IFI_CANFD_TXSTCMD_REMOVE_PEND_MSG	BIT(6)
#define IFI_CANFD_TXSTCMD_RESET			BIT(7)
#define IFI_CANFD_TXSTCMD_EMPTY			BIT(8)
#define IFI_CANFD_TXSTCMD_FULL			BIT(12)
#define IFI_CANFD_TXSTCMD_OVERFLOW		BIT(13)

#define IFI_CANFD_INTERRUPT			0xc
#define IFI_CANFD_INTERRUPT_ERROR_BUSOFF	BIT(0)
#define IFI_CANFD_INTERRUPT_ERROR_WARNING	BIT(1)
#define IFI_CANFD_INTERRUPT_ERROR_STATE_CHG	BIT(2)
#define IFI_CANFD_INTERRUPT_ERROR_REC_TEC_INC	BIT(3)
#define IFI_CANFD_INTERRUPT_ERROR_COUNTER	BIT(10)
#define IFI_CANFD_INTERRUPT_TXFIFO_EMPTY	BIT(16)
#define IFI_CANFD_INTERRUPT_TXFIFO_OVERFLOW	BIT(21)
#define IFI_CANFD_INTERRUPT_TXFIFO_REMOVE	BIT(22)
#define IFI_CANFD_INTERRUPT_RXFIFO_NEMPTY	BIT(24)
#define IFI_CANFD_INTERRUPT_RXFIFO_NEMPTY_PER	BIT(25)
#define IFI_CANFD_INTERRUPT_RXFIFO_OVERFLOW	BIT(30)
#define IFI_CANFD_INTERRUPT_SET_IRQ		((u32)BIT(31))

#define IFI_CANFD_IRQMASK			0x10
#define IFI_CANFD_IRQMASK_ERROR_BUSOFF		BIT(0)
#define IFI_CANFD_IRQMASK_ERROR_WARNING		BIT(1)
#define IFI_CANFD_IRQMASK_ERROR_STATE_CHG	BIT(2)
#define IFI_CANFD_IRQMASK_ERROR_REC_TEC_INC	BIT(3)
#define IFI_CANFD_IRQMASK_SET_ERR		BIT(7)
#define IFI_CANFD_IRQMASK_SET_TS		BIT(15)
#define IFI_CANFD_IRQMASK_TXFIFO_EMPTY		BIT(16)
#define IFI_CANFD_IRQMASK_SET_TX		BIT(23)
#define IFI_CANFD_IRQMASK_RXFIFO_NEMPTY		BIT(24)
#define IFI_CANFD_IRQMASK_RXFIFO_OVERFLOW	BIT(30)
#define IFI_CANFD_IRQMASK_SET_RX		((u32)BIT(31))

#define IFI_CANFD_TIME				0x14
#define IFI_CANFD_FTIME				0x18
#define IFI_CANFD_TIME_TIMEB_OFF		0
#define IFI_CANFD_TIME_TIMEA_OFF		8
#define IFI_CANFD_TIME_PRESCALE_OFF		16
#define IFI_CANFD_TIME_SJW_OFF_7_9_8_8		25
#define IFI_CANFD_TIME_SJW_OFF_4_12_6_6		28
#define IFI_CANFD_TIME_SET_SJW_4_12_6_6		BIT(6)
#define IFI_CANFD_TIME_SET_TIMEB_4_12_6_6	BIT(7)
#define IFI_CANFD_TIME_SET_PRESC_4_12_6_6	BIT(14)
#define IFI_CANFD_TIME_SET_TIMEA_4_12_6_6	BIT(15)

#define IFI_CANFD_TDELAY			0x1c
#define IFI_CANFD_TDELAY_DEFAULT		0xb
#define IFI_CANFD_TDELAY_MASK			0x3fff
#define IFI_CANFD_TDELAY_ABS			BIT(14)
#define IFI_CANFD_TDELAY_EN			BIT(15)

#define IFI_CANFD_ERROR				0x20
#define IFI_CANFD_ERROR_TX_OFFSET		0
#define IFI_CANFD_ERROR_TX_MASK			0xff
#define IFI_CANFD_ERROR_RX_OFFSET		16
#define IFI_CANFD_ERROR_RX_MASK			0xff

#define IFI_CANFD_ERRCNT			0x24

#define IFI_CANFD_SUSPEND			0x28

#define IFI_CANFD_REPEAT			0x2c

#define IFI_CANFD_TRAFFIC			0x30

#define IFI_CANFD_TSCONTROL			0x34

#define IFI_CANFD_TSC				0x38

#define IFI_CANFD_TST				0x3c

#define IFI_CANFD_RES1				0x40

#define IFI_CANFD_ERROR_CTR			0x44
#define IFI_CANFD_ERROR_CTR_UNLOCK_MAGIC	0x21302899
#define IFI_CANFD_ERROR_CTR_OVERLOAD_FIRST	BIT(0)
#define IFI_CANFD_ERROR_CTR_ACK_ERROR_FIRST	BIT(1)
#define IFI_CANFD_ERROR_CTR_BIT0_ERROR_FIRST	BIT(2)
#define IFI_CANFD_ERROR_CTR_BIT1_ERROR_FIRST	BIT(3)
#define IFI_CANFD_ERROR_CTR_STUFF_ERROR_FIRST	BIT(4)
#define IFI_CANFD_ERROR_CTR_CRC_ERROR_FIRST	BIT(5)
#define IFI_CANFD_ERROR_CTR_FORM_ERROR_FIRST	BIT(6)
#define IFI_CANFD_ERROR_CTR_OVERLOAD_ALL	BIT(8)
#define IFI_CANFD_ERROR_CTR_ACK_ERROR_ALL	BIT(9)
#define IFI_CANFD_ERROR_CTR_BIT0_ERROR_ALL	BIT(10)
#define IFI_CANFD_ERROR_CTR_BIT1_ERROR_ALL	BIT(11)
#define IFI_CANFD_ERROR_CTR_STUFF_ERROR_ALL	BIT(12)
#define IFI_CANFD_ERROR_CTR_CRC_ERROR_ALL	BIT(13)
#define IFI_CANFD_ERROR_CTR_FORM_ERROR_ALL	BIT(14)
#define IFI_CANFD_ERROR_CTR_BITPOSITION_OFFSET	16
#define IFI_CANFD_ERROR_CTR_ERROR_FIRST_MASK	0x000000FF
#define IFI_CANFD_ERROR_CTR_ERROR_ALL_MASK	0x00007F00
#define IFI_CANFD_ERROR_CTR_BITPOSITION_MASK	0x03ff0000
#define IFI_CANFD_ERROR_CTR_ERRORFRAME_RESET	BIT(26)
#define IFI_CANFD_ERROR_CTR_OVERLOAD_RESET	BIT(27)
#define IFI_CANFD_ERROR_CTR_ERRORFRAME_PEND	BIT(28)
#define IFI_CANFD_ERROR_CTR_OVERLOAD_PEND	BIT(29)
#define IFI_CANFD_ERROR_CTR_ER_RESET		BIT(30)
#define IFI_CANFD_ERROR_CTR_ER_ENABLE		((u32)BIT(31))

#define IFI_CANFD_PAR				0x48
#define IFI_CANFD_PAR_TX_SIZE			0x000000FF
#define IFI_CANFD_PAR_RX_SIZE			0x0000FF00
#define IFI_CANFD_PAR_SINGLE_CLOCK		BIT(16)
#define IFI_CANFD_PAR_NO_TSTAMP			BIT(17)
#define IFI_CANFD_PAR_NO_FILTER			BIT(18)
#define IFI_CANFD_PAR_NO_BUSSTAT		BIT(19)

#define IFI_CANFD_CANCLOCK			0x4c

#define IFI_CANFD_SYSCLOCK			0x50

#define IFI_CANFD_VER				0x54
#define IFI_CANFD_VER_REV_MASK			0xff
#define IFI_CANFD_VER_REV_MIN_SUPPORTED		0x15

#define IFI_CANFD_IP_ID				0x58
#define IFI_CANFD_IP_ID_VALUE			0xD073CAFD

#define IFI_CANFD_TEST				0x5c

#define IFI_CANFD_RXFIFO_TS_63_32		0x60

#define IFI_CANFD_RXFIFO_TS_31_0		0x64

#define IFI_CANFD_RXFIFO_DLC			0x68
#define IFI_CANFD_RXFIFO_DLC_DLC_OFFSET		0
#define IFI_CANFD_RXFIFO_DLC_DLC_MASK		0xf
#define IFI_CANFD_RXFIFO_DLC_RTR		BIT(4)
#define IFI_CANFD_RXFIFO_DLC_EDL		BIT(5)
#define IFI_CANFD_RXFIFO_DLC_BRS		BIT(6)
#define IFI_CANFD_RXFIFO_DLC_ESI		BIT(7)
#define IFI_CANFD_RXFIFO_DLC_OBJ_OFFSET		8
#define IFI_CANFD_RXFIFO_DLC_OBJ_MASK		0x0001ff00
#define IFI_CANFD_RXFIFO_DLC_FNR_OFFSET		24
#define IFI_CANFD_RXFIFO_DLC_FNR_MASK		0xff000000

#define IFI_CANFD_RXFIFO_ID			0x6c
#define IFI_CANFD_RXFIFO_ID_ID_OFFSET		0
#define IFI_CANFD_RXFIFO_ID_ID_STD_MASK		CAN_SFF_MASK
#define IFI_CANFD_RXFIFO_ID_ID_STD_OFFSET	0
#define IFI_CANFD_RXFIFO_ID_ID_STD_WIDTH	10
#define IFI_CANFD_RXFIFO_ID_ID_XTD_MASK		CAN_EFF_MASK
#define IFI_CANFD_RXFIFO_ID_ID_XTD_OFFSET	11
#define IFI_CANFD_RXFIFO_ID_ID_XTD_WIDTH	18
#define IFI_CANFD_RXFIFO_ID_IDE			BIT(29)

#define IFI_CANFD_RXFIFO_DATA			0x70

#define IFI_CANFD_TXFIFO_SUSPEND_US		0xb0

#define IFI_CANFD_TXFIFO_REPEATCOUNT		0xb4

#define IFI_CANFD_TXFIFO_DLC			0xb8
#define IFI_CANFD_TXFIFO_DLC_DLC_OFFSET		0
#define IFI_CANFD_TXFIFO_DLC_DLC_MASK		0xf
#define IFI_CANFD_TXFIFO_DLC_RTR		BIT(4)
#define IFI_CANFD_TXFIFO_DLC_EDL		BIT(5)
#define IFI_CANFD_TXFIFO_DLC_BRS		BIT(6)
#define IFI_CANFD_TXFIFO_DLC_FNR_OFFSET		24
#define IFI_CANFD_TXFIFO_DLC_FNR_MASK		0xff

#define IFI_CANFD_TXFIFO_ID			0xbc
#define IFI_CANFD_TXFIFO_ID_ID_OFFSET		0
#define IFI_CANFD_TXFIFO_ID_ID_STD_MASK		CAN_SFF_MASK
#define IFI_CANFD_TXFIFO_ID_ID_STD_OFFSET	0
#define IFI_CANFD_TXFIFO_ID_ID_STD_WIDTH	10
#define IFI_CANFD_TXFIFO_ID_ID_XTD_MASK		CAN_EFF_MASK
#define IFI_CANFD_TXFIFO_ID_ID_XTD_OFFSET	11
#define IFI_CANFD_TXFIFO_ID_ID_XTD_WIDTH	18
#define IFI_CANFD_TXFIFO_ID_IDE			BIT(29)

#define IFI_CANFD_TXFIFO_DATA			0xc0

#define IFI_CANFD_FILTER_MASK(n)		(0x800 + ((n) * 8) + 0)
#define IFI_CANFD_FILTER_MASK_EXT		BIT(29)
#define IFI_CANFD_FILTER_MASK_EDL		BIT(30)
#define IFI_CANFD_FILTER_MASK_VALID		((u32)BIT(31))

#define IFI_CANFD_FILTER_IDENT(n)		(0x800 + ((n) * 8) + 4)
#define IFI_CANFD_FILTER_IDENT_IDE		BIT(29)
#define IFI_CANFD_FILTER_IDENT_CANFD		BIT(30)
#define IFI_CANFD_FILTER_IDENT_VALID		((u32)BIT(31))

#define IFI_CANFD_CUSTOM_IRQ_HANDLING		0x1

#define IFI_CANFD_DEFAULT_RESTART_MS		100

#define IFI_CANFD_E_FAILED		0xFFFFFFFF

/**
 * struct ixxat_can_msg_base - IXXAT CAN message base (CL1/CL2)
 * @can: CAN common private data
 * @napi: Structure for NAPI scheduling
 * @ndev: Network Device data
 * @base: Base address
 * @priv: additional field for device specific programming
 * @flags: custom mode flags
 * @pre_irq: function pointers for custom pre-irq functionality
 * @post_irq: function pointers for custom post-irq functionality
 *
 * Contains the common fields of an IXXAT CAN message on both CL1 and CL2
 * devices
 */
struct ifi_canfd_priv {
	struct can_priv		can;	/* must be the first member */
	struct napi_struct	napi;
	struct net_device	*ndev;
	void __iomem		*base;

	void			*priv;
	u16			flags;	/* custom mode flags*/

	void (*pre_irq)(const struct ifi_canfd_priv *priv);
	void (*post_irq)(const struct ifi_canfd_priv *priv);

	u64		msgs;
	u32		msg_index;
};

/**
 * ifi_canfd_isr()
 * @irq: IRQ Number
 * @dev_id: Device ID
 *
 * This function is executed on reception of an interrupt
 *
 * Return: Interrupt handling status
 */
irqreturn_t ifi_canfd_isr(int irq, void *dev_id);

/**
 * ifi_canfd_irq_enable() - Enable/disable interrupt mode
 * @ndev: Network device (CAN)
 * @enable: flag 1-enable,0-disable
 * @clear: flag to clear interrupts when set to 1
 *
 * This function enables/disables/clears interrupts on request
 *
 * Return: None
 */
void ifi_canfd_irq_enable(struct net_device *ndev, bool enable, u8 clear);

/**
 * ifi_canfd_set_bittiming() - Set CAN bit timings
 * @ndev: Network device (CAN)
 *
 * This function sets CAN bit timings and data bit timings
 *
 * Return: None
 */
void ifi_canfd_set_bittiming(struct net_device *ndev);

/**
 * ifi_canfd_set_filters() - Set Filter masks and IDs
 * @ndev: Network device (CAN)
 * @enable: enable/disable flag
 *
 * This function sets Filter masks and IDs for Standard and extended CAN frames
 * and CANFD Frames
 *
 * Return: None
 */
void ifi_canfd_set_filters(struct net_device *ndev, bool enable);

/**
 * ifi_canfd_poll() - NAPI polling function
 * @napi:
 * @quota: This parameter places a limit on the amount of work the driver may
 *         do. If and only if the return value is less than the budget, your
 *         driver must reenable interrupts and turn off polling
 *
 * This function polls the driver shortly to pick up all available packets when
 * interrupt is being serviced
 *
 * Return: No. of packets processed
 */
int ifi_canfd_poll(struct napi_struct *napi, int quota);

/**
 * alloc_ifi_canfd_dev() - Allocate CAN device
 * @sizeof_priv: size of device interface
 * @echo_skb_max: max. number of sockets
 *
 * This function allocates a CAN device
 *
 * Return: Network device allocated
 */
struct net_device *alloc_ifi_canfd_dev(int sizeof_priv, int echo_skb_max);

/**
 * free_ifi_canfd_dev() - Free CAN device
 * @ndev: Network device (CAN)
 *
 * This function frees previously allocated CAN device
 *
 * Return: None
 */
void free_ifi_canfd_dev(struct net_device *ndev);

/**
 * register_ifi_canfd_dev() - Register CAN device
 * @ndev: Network device (CAN)
 *
 * This function registers CAN device and sets netdev_ops structure
 *
 * Return: return code register_candev
 */
int register_ifi_canfd_dev(struct net_device *ndev);

/**
 * unregister_ifi_canfd_dev() - Unregister CAN device
 * @ndev: Network device (CAN)
 *
 * This function unregisters CAN device
 *
 * Return: None
 */
void unregister_ifi_canfd_dev(struct net_device *ndev);

#endif /* IFIFD_PATCH_IFI_CANFD_H_ */


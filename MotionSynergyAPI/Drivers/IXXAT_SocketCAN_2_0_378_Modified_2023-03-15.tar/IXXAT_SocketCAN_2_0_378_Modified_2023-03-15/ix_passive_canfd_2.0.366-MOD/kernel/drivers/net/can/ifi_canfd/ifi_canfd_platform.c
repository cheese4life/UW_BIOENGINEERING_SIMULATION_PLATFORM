// SPDX-License-Identifier: GPL-2.0

/* CAN bus driver for IFI CANFD controller
 *
 * Copyright (C) 2016 Marek Vasut <marex@denx.de>
 *
 * Details about this controller can be found at
 * http://www.ifi-pld.de/IP/CANFD/canfd.html
 *
 * This file is licensed under the terms of the GNU General Public
 * License version 2. This program is licensed "as is" without any
 * warranty of any kind, whether express or implied.
 */

#include <linux/clk.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/platform_device.h>

#include <linux/can/dev.h>
#include "ifi_canfd.h"

MODULE_AUTHOR("Marek Vasut <marex@denx.de>");
MODULE_DESCRIPTION("CAN bus driver for IFI CANFD controller");
MODULE_LICENSE("GPL v2");

static int ifi_canfd_plat_probe(struct platform_device *pdev)
{
	struct device *dev = &pdev->dev;
	struct net_device *ndev;
	struct ifi_canfd_priv *priv;
	struct resource *res;
	void __iomem *addr;
	int irq, ret;
	u32 id, rev;
	u32 txsize, min_msg_size, max_num;

	res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
	addr = devm_ioremap_resource(dev, res);
	irq = platform_get_irq(pdev, 0);
	if (IS_ERR(addr) || irq < 0)
		return -EINVAL;

	id = readl(addr + IFI_CANFD_IP_ID);
	if (id != IFI_CANFD_IP_ID_VALUE) {
		dev_err(dev, "This block is not IFI CANFD, id=%08x\n", id);
		return -EINVAL;
	}

	rev = readl(addr + IFI_CANFD_VER) & IFI_CANFD_VER_REV_MASK;
	if (rev < IFI_CANFD_VER_REV_MIN_SUPPORTED) {
		dev_err(dev, "This block is too old (rev %i), minimum supported is rev %i\n",
			rev, IFI_CANFD_VER_REV_MIN_SUPPORTED);
		return -EINVAL;
	}
  
	txsize = readl(addr + IFI_CANFD_PAR) & IFI_CANFD_PAR_TX_SIZE;
	min_msg_size = 16; // minimal size of one CAN message 
	max_num = (txsize * 1024) / min_msg_size;

	ndev = alloc_ifi_canfd_dev(0, max_num);
	if (!ndev)
		return -ENOMEM;

	priv = netdev_priv(ndev);

	priv->can.state = CAN_STATE_STOPPED;
	priv->can.clock.freq = readl(addr + IFI_CANFD_CANCLOCK);

	ndev->irq = irq;
	priv->base = addr;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 18, 0)
        netif_napi_add_weight(ndev, &priv->napi, ifi_canfd_poll, NAPI_POLL_WEIGHT);
#else
	netif_napi_add(ndev, &priv->napi, ifi_canfd_poll, NAPI_POLL_WEIGHT);
#endif

	platform_set_drvdata(pdev, ndev);
	SET_NETDEV_DEV(ndev, dev);

	ret = register_ifi_canfd_dev(ndev);
	if (ret) {
		dev_err(dev, "Failed to register (ret=%d)\n", ret);
		goto err_reg;
	}

	dev_info(dev, "Driver registered: regs=%p, irq=%d, clock=%d\n",
		 priv->base, ndev->irq, priv->can.clock.freq);

	return 0;

err_reg:
	free_ifi_canfd_dev(ndev);
	return ret;
}

static int ifi_canfd_plat_remove(struct platform_device *pdev)
{
	struct net_device *ndev = platform_get_drvdata(pdev);

	unregister_ifi_canfd_dev(ndev);
	platform_set_drvdata(pdev, NULL);
	free_ifi_canfd_dev(ndev);

	return 0;
}

static const struct of_device_id ifi_canfd_of_table[] = {
	{ .compatible = "ifi,canfd-1.0", .data = NULL },
	{ /* sentinel */ },
};
MODULE_DEVICE_TABLE(of, ifi_canfd_of_table);

static struct platform_driver ifi_canfd_plat_driver = {
	.driver = {
		.name		= KBUILD_MODNAME,
		.of_match_table	= ifi_canfd_of_table,
	},
	.probe	= ifi_canfd_plat_probe,
	.remove	= ifi_canfd_plat_remove,
};

module_platform_driver(ifi_canfd_plat_driver);

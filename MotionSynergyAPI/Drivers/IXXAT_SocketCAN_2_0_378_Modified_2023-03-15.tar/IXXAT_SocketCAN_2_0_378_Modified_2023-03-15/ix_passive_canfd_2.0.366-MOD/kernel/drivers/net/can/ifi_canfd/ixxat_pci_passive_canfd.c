// SPDX-License-Identifier: GPL-2.0

/* CAN driver base for IXXAT PCI-to-CAN
 *
 * Copyright (C) 2018 HMS Industrial Networks <socketcan@hms-networks.de>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published
 * by the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 */

#include <linux/module.h>
#include <linux/pci.h>
#include <linux/can/dev.h>

#include "ifi_canfd.h"

MODULE_AUTHOR("HMS Technology Center Ravensburg Gmbh <socketcan@hms-networks.de>");
MODULE_DESCRIPTION("SocketCAN driver for HMS Ixxat IB500, IB520 boards");
MODULE_LICENSE("GPL v2");
MODULE_VERSION("2.0.366-REL");

#if defined(CONFIG_TRACING) && defined(DEBUG)
	#define ix_trace_printk(...) trace_printk(__VA_ARGS__)
#else
	#define ix_trace_printk(...)
#endif

//#define IXXAT_PCI_DRIVER_NAME KBUILD_MODNAME
#define IXXAT_PCI_VENDOR_ID 0x1BEE

#define IXXAT_PCI_CLOCK 80000000

/* CAN FD - Supported Devices */
#define CAN_IB500_PRODUCT_ID 0x000e
#define CAN_IB510_PRODUCT_ID 0x0017
#define CAN_IB520_PRODUCT_ID 0x0012
#define CAN_IB700_PRODUCT_ID 0x0019
#define CAN_IB710_PRODUCT_ID 0x001A

#define IXXAT_PCI_CANFD_MODES (CAN_CTRLMODE_LISTENONLY | \
	CAN_CTRLMODE_ONE_SHOT | \
	CAN_CTRLMODE_LOOPBACK | \
	CAN_CTRLMODE_BERR_REPORTING | \
	CAN_CTRLMODE_FD | \
	CAN_CTRLMODE_FD_NON_ISO)

#define IXXAT_PCI_CARDNAME_BASE 0x0000
#define IXXAT_PCI_CARDNAME_SIZE 0x0010
#define IXXAT_PCI_HWSERIAL_SIZE 0x0010

#define IXXAT_PCI_IFI_CAN_BASE 0x2000
#define IXXAT_PCI_IFI_CAN_SIZE 0x1000

/* FPGA Version */
#define IXXAT_PCI_FPGA_BASE 0x0020

/* Hardware Version */
#define IXXAT_PCI_HW_BASE 0x0010

/* Sync I/O */
#define IXXAT_PCI_SYNCIO_BASE 0x0060

/* GPIO SPI */
#define IXXAT_PCI_GPIOSPI_BASE 0x0080

/* SYNC I/O bit encoding */
#define IXXAT_PCI_SIO_EXPANSION 0x0004 // Flag if 2 CAN expansion board attached

/* Variant coding */
#define IXXAT_PCI_VARIANT_BASE 0x1000
#define IXXAT_PCI_VARIANT_STEP 0x0100
#define IXXAT_PCI_VARIANT_COUNT 0x0004

/* Variant encoding */
#define IXXAT_PCI_VC_CANHS 1 // BIT 0 CAN HS present
#define IXXAT_PCI_VC_MASK 0x001F // variant bit mask
#define IXXAT_PCI_VC_CANLS 2 // CAN LowSpeed extension board installed
#define IXXAT_PCI_VC_CANLS_LIN 4 // CAN LowSpeed / K-Line extension board installed
#define IXXAT_PCI_VC_CANLS_KLINE 5 // CAN LowSpeed / LIN extension board installed

#define PCIE_ALTERA_LCR_INTCSR 0x0040
#define PCIE_ALTERALCR_A2P_INTENA 0x0050

#define IXXAT_PCI_ENABLE_INT 0x00000080
#define IXXAT_PCI_DISABLE_INT 0xFFFFFF7F

#define IXXAT_PCI_BUS_CAN 1
#define IXXAT_PCI_BUS_TYPE(busctrl) ((u8)(((busctrl) >> 8) & 0x00FF))

#define IXXAT_PCI_MAX_TX_TRANS 0x10

#define IXXAT_PCI_EPCS_READ_BYTES 0x03

#define IXXAT_PCI_INFO_SECTOR 31
#define IXXAT_PCI_INFO_SECTOR_SIZE 0x10000

#define IXXAT_PCI_BSP_FPGA_SCF_NCS 0
#define IXXAT_PCI_BSP_FPGA_SCF_CLK 1
#define IXXAT_PCI_BSP_FPGA_SCF_SDI 2
#define IXXAT_PCI_BSP_FPGA_SCF_SDO 3

#define IXXAT_PCI_MAX_CHAN 4
#define IXXAT_PCI_PINMASK 0x01
#define IXXAT_PCI_BUS_SHIFT 8

static struct pci_device_id ixxat_pci_table[] = {
	{ PCI_DEVICE(IXXAT_PCI_VENDOR_ID, CAN_IB500_PRODUCT_ID) },
	{ PCI_DEVICE(IXXAT_PCI_VENDOR_ID, CAN_IB510_PRODUCT_ID) },
	{ PCI_DEVICE(IXXAT_PCI_VENDOR_ID, CAN_IB520_PRODUCT_ID) },
	{ PCI_DEVICE(IXXAT_PCI_VENDOR_ID, CAN_IB700_PRODUCT_ID) },
	{ PCI_DEVICE(IXXAT_PCI_VENDOR_ID, CAN_IB710_PRODUCT_ID) },
	{ },
};

struct ixxat_intf_caps {
	u16 bus_ctrl_count;
	u16 bus_ctrl_types[32];
	u16 reserved;
} __packed;

struct ixxat_intf_info {
	char intf_name[IXXAT_PCI_CARDNAME_SIZE]; // device name
	char intf_id[IXXAT_PCI_HWSERIAL_SIZE]; // unique device id
	u16 intf_version; // device version ( 0, 1, ...)
	u32 fpga_version; // device version of FPGA design
	u16 reserved;
} __packed;

struct ixxat_pci_interface {
	u16 ctrl_idx;
	struct pci_dev *pdev;
	struct net_device *ndev[IXXAT_PCI_MAX_CHAN];

	int irqHandled [IXXAT_PCI_MAX_CHAN];

	phys_addr_t reg1add;
	void __iomem *reg1vadd;
	unsigned long reg1len;

	/* Interface PCI(e) memory */
	phys_addr_t memadd;
	void __iomem *memvadd;
	unsigned long memlen;

	u16 ctrl_cnt;
	spinlock_t dev_lock;
	struct ixxat_intf_info intf_info;
};
MODULE_DEVICE_TABLE(pci, ixxat_pci_table);

static int ixxat_pci_int_ena_req(struct ixxat_pci_interface *intf, u8 enable)
{
	u32 regval = ioread32(intf->reg1vadd + PCIE_ALTERALCR_A2P_INTENA);

	if (enable)
		iowrite32(regval | IXXAT_PCI_ENABLE_INT,
			  intf->reg1vadd + PCIE_ALTERALCR_A2P_INTENA);
	else
		iowrite32(regval & IXXAT_PCI_DISABLE_INT,
			  intf->reg1vadd + PCIE_ALTERALCR_A2P_INTENA);

	return (0 != (regval & IXXAT_PCI_ENABLE_INT));
}

static void ixxat_pci_int_clr_req(struct ixxat_pci_interface *intf)
{
	u32 regval = ioread32(intf->reg1vadd + PCIE_ALTERA_LCR_INTCSR);

	iowrite32(regval, intf->reg1vadd + PCIE_ALTERA_LCR_INTCSR);
}

static void ixxat_pci_post_irq(const struct ifi_canfd_priv *priv)
{
//  there is no clear interrupt necessary or possible
//  the interrupt can only reseted through the IFI CAN controller
}

static void ixxat_pci_pre_irq(const struct ifi_canfd_priv *priv)
{
//  there is no clear interrupt necessary or possible
//  the interrupt can only reseted through the IFI CAN controller
}

static void ixxat_pci_gpio_set_pin(void __iomem *gpio_base, u32 pin, u8 val)
{
	u8 act_val;
	u8 mask = (IXXAT_PCI_PINMASK << pin);

	if (!gpio_base)
		return;

	act_val = ioread32(gpio_base);

	if (!val)
		act_val &= ~mask;
	else
		act_val |= mask;

	iowrite32(act_val, gpio_base);
}

static void ixxat_pci_gpio_write_byte(void __iomem *gpio_base, u8 data)
{
	int i;

	for (i = (sizeof(u8) * 8) - 1; i >= 0; i--) {
		ixxat_pci_gpio_set_pin(gpio_base, IXXAT_PCI_BSP_FPGA_SCF_CLK, 0);
		ixxat_pci_gpio_set_pin(gpio_base, IXXAT_PCI_BSP_FPGA_SCF_SDI,
				       (data >> i) & 0x01);
		ixxat_pci_gpio_set_pin(gpio_base, IXXAT_PCI_BSP_FPGA_SCF_CLK, 1);
	}
}

static u8 ixxat_pci_gpio_read_byte(void __iomem *gpio_base)
{
	u8 data = 0;
	int i;

	for (i = (sizeof(u8) * 8) - 1; i >= 0; i--) {
		ixxat_pci_gpio_set_pin(gpio_base, IXXAT_PCI_BSP_FPGA_SCF_CLK, 1);
		ixxat_pci_gpio_set_pin(gpio_base, IXXAT_PCI_BSP_FPGA_SCF_CLK, 0);
		data |= (((ioread32(gpio_base) >>
			IXXAT_PCI_BSP_FPGA_SCF_SDO) & 0x01) << i);
	}

	return data;
}

static int ixxat_pci_read_serial(struct ixxat_pci_interface *intf,
				 u8 max_size, char *hw_serial)
{
	int i;
	void __iomem *gpio_base = intf->memvadd + IXXAT_PCI_GPIOSPI_BASE;
	u32 addr = IXXAT_PCI_INFO_SECTOR_SIZE * IXXAT_PCI_INFO_SECTOR;

	ixxat_pci_gpio_set_pin(gpio_base, IXXAT_PCI_BSP_FPGA_SCF_NCS, 0);
	ixxat_pci_gpio_write_byte(gpio_base, IXXAT_PCI_EPCS_READ_BYTES);
	ixxat_pci_gpio_write_byte(gpio_base, (addr >> 16) & 0xFF);
	ixxat_pci_gpio_write_byte(gpio_base, (addr >> 8) & 0xFF);
	ixxat_pci_gpio_write_byte(gpio_base, (addr) & 0xFF);

	for (i = 0; i < (IXXAT_PCI_HWSERIAL_SIZE - 1); i++)
		*hw_serial++ = ixxat_pci_gpio_read_byte(gpio_base);

	ixxat_pci_gpio_set_pin(gpio_base, IXXAT_PCI_BSP_FPGA_SCF_NCS, 1);

	if (hw_serial[0] == ((char)0xFF))
		return -EIO;

	return 0;
}

static int ixxat_pci_get_intf_info(struct ixxat_pci_interface *intf,
				   struct ixxat_intf_info *intf_info)
{
	/* Reset return structure */
	memset(intf_info, 0, sizeof(*intf_info));

	/* Copy board name */
	memcpy_fromio(intf_info->intf_name,
		      (intf->memvadd + IXXAT_PCI_CARDNAME_BASE),
		      min(sizeof(intf_info->intf_name) - 1,
			  (size_t)IXXAT_PCI_CARDNAME_SIZE));

	/* Copy Version Info */
	intf_info->intf_version = ioread16(intf->memvadd + IXXAT_PCI_HW_BASE);
	intf_info->fpga_version = ioread32(intf->memvadd
		+ IXXAT_PCI_FPGA_BASE);

	/* Read hardware serial number */
	return ixxat_pci_read_serial(intf, sizeof(intf_info->intf_id) - 1,
		intf_info->intf_id);
}

static int ixxat_pci_get_intf_caps(struct pci_dev *pdev,
				   struct ixxat_pci_interface *intf,
				   struct ixxat_intf_caps *intf_caps)
{
	int i;
	u8 has_expansion_board = 0;
	char card_name[IXXAT_PCI_CARDNAME_SIZE];
	u32 variant;
	u8 is_high_speed;
	u8 is_low_speed;

	/* Reset return structure */
	memset(intf_caps, 0, sizeof(*intf_caps));

	/* Show Board Info */
	memcpy_fromio(card_name, intf->memvadd + IXXAT_PCI_CARDNAME_BASE,
		      sizeof(card_name) - 1);

	dev_info(&pdev->dev, "Card Name     : %s\n", card_name);
	dev_info(&pdev->dev, "HW Version    : 0x%04X\n",
		 ioread16(intf->memvadd + IXXAT_PCI_HW_BASE));
	dev_info(&pdev->dev, "FPGA Version  : 0x%08X\n",
		 ioread32(intf->memvadd + IXXAT_PCI_FPGA_BASE));

	/* Check if expansion board is present */
	if (IXXAT_PCI_SIO_EXPANSION == (ioread32(intf->memvadd
						+ IXXAT_PCI_SYNCIO_BASE) &
					IXXAT_PCI_SIO_EXPANSION))
		has_expansion_board = 1;

	/* Iterate over all variant register */
	for (i = 0; i < IXXAT_PCI_VARIANT_COUNT; i++) {
		is_high_speed = 0;
		is_low_speed = 0;

		variant = ioread32(intf->memvadd + IXXAT_PCI_VARIANT_BASE
			+ IXXAT_PCI_VARIANT_STEP * i);

		/* Check if CAN HighSpeed is present on extension board */
		/* ECI_IB5X0_VC_CANHS is set always for CAN3 and CAN4 */
		if (i < 2 || has_expansion_board)
			/* Check if CAN HighSpeed is present */
			if (variant & IXXAT_PCI_VC_CANHS)
				is_high_speed = 1;

		/* Check what type of extension board is attached */
		variant = ~(variant >> 1);
		variant &= IXXAT_PCI_VC_MASK;

		switch (variant) {
		case IXXAT_PCI_VC_CANLS:
		case IXXAT_PCI_VC_CANLS_LIN:
		case IXXAT_PCI_VC_CANLS_KLINE:
			is_low_speed = 1;
			break;
		default:
			break;
		}

		/* CAN Controller */
		if ((is_high_speed | is_low_speed) &&
		    (ARRAY_SIZE(intf_caps->bus_ctrl_types) >
		    intf_caps->bus_ctrl_count))
			intf_caps->bus_ctrl_types[intf_caps->bus_ctrl_count++] =
				IXXAT_PCI_BUS_CAN << IXXAT_PCI_BUS_SHIFT;
	}

	return 0;
}

static int ixxat_pci_register_dev(struct pci_dev *pdev,
				  struct ixxat_pci_interface *intf)
{
	int err = -ENOMEM;

	intf->reg1add = pci_resource_start(pdev, 0);
	intf->reg1len = pci_resource_len(pdev, 0);

	intf->memadd = pci_resource_start(pdev, 2);
	intf->memlen = pci_resource_len(pdev, 2);

	request_mem_region(intf->reg1add, intf->reg1len, "IXXAT PCI Registers");
	intf->reg1vadd = ioremap(intf->reg1add, intf->reg1len);
	if (!intf->reg1vadd) {
		dev_err(&pdev->dev, "Error: reg1vadd ioremap_nocache failed\n");
		goto fail;
	}

	request_mem_region(intf->memadd, intf->memlen, "IXXAT PCI Memory");
	intf->memvadd = ioremap(intf->memadd, intf->memlen);
	if (!intf->memvadd) {
		dev_err(&pdev->dev, "Error: memvadd ioremap_nocache failed\n");
		goto release_reg1;
	}

	return 0;

release_reg1:
	iounmap(intf->reg1vadd);
	release_mem_region(intf->reg1add, intf->reg1len);
fail:
	return err;
}

static int ixxat_pci_create_dev(struct ixxat_pci_interface *intf,
				struct pci_dev *pdev,
				int ctrl_idx)
{
	u32 ifi_sts_cmd;
	int err;
	struct ifi_canfd_priv *priv;
	struct net_device *ndev;
	u32 txsize, min_msg_size, max_num;
	void __iomem *mem_base = intf->memvadd + IXXAT_PCI_IFI_CAN_BASE
		+ ctrl_idx * IXXAT_PCI_IFI_CAN_SIZE;

	txsize = readl(mem_base + IFI_CANFD_PAR) & IFI_CANFD_PAR_TX_SIZE;
	min_msg_size = 16; // minimal size of one CAN message
	max_num = (txsize * 1024) / min_msg_size;

	ndev = alloc_ifi_canfd_dev(sizeof(*intf), max_num);
	if (!ndev)
		return -ENOMEM;

	intf->ndev[ctrl_idx] = ndev;
	priv = netdev_priv(ndev);
	priv->priv = intf;

	priv->can.state = CAN_STATE_STOPPED;
	priv->can.clock.freq = IXXAT_PCI_CLOCK;

	priv->base = mem_base;
	priv->post_irq = ixxat_pci_post_irq;
	priv->pre_irq  = ixxat_pci_pre_irq;
	ndev->irq = pdev->irq;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 18, 0)
        netif_napi_add_weight(ndev, &priv->napi, ifi_canfd_poll, 2);
#else
	netif_napi_add(ndev, &priv->napi, ifi_canfd_poll, 2);
#endif
	SET_NETDEV_DEV(ndev, &pdev->dev);
	ndev->dev_id = ctrl_idx;

	err = register_ifi_canfd_dev(ndev);
	if (err) {
		dev_err(&intf->pdev->dev,
			"Error %d: Failed to register Can device\n", err);
		goto free_candev;
	}

	intf->ctrl_idx = ctrl_idx;

	ifi_canfd_set_filters(ndev, false);
	ifi_canfd_irq_enable(ndev, 0, 1);

	ifi_sts_cmd = ioread32(priv->base + IFI_CANFD_STCMD);
	ifi_sts_cmd |= IFI_CANFD_STCMD_ENABLE_7_9_8_8_TIMING;
	iowrite32(ifi_sts_cmd, priv->base + IFI_CANFD_STCMD);

	err = ixxat_pci_get_intf_info(intf, &intf->intf_info);
	if (err) {
		dev_err(&intf->pdev->dev,
			"Error %d: Failed to get device information\n", err);
		goto unreg_candev;
	}

	netdev_info(ndev, "%s: Connected Channel %u (device %s)\n",
		    intf->intf_info.intf_name, ctrl_idx,
		    intf->intf_info.intf_id);

	return 0;

unreg_candev:
	unregister_ifi_canfd_dev(ndev);
free_candev:
	free_ifi_canfd_dev(ndev);

	return err;
}

static void ixxat_pci_free(struct ixxat_pci_interface *intf)
{
	if (!intf)
		return;

	ixxat_pci_int_ena_req(intf, 0);

	iounmap(intf->reg1vadd);
	release_mem_region(intf->reg1add, intf->reg1len);

	iounmap(intf->memvadd);
	release_mem_region(intf->memadd, intf->memlen);
}

static void ixxat_pci_remove(struct pci_dev *pdev)
{
	struct ixxat_pci_interface *intf = pci_get_drvdata(pdev);
	struct net_device *ndev;
	int i;

	/* unregister the given device and all previous devices */
	for (i = 0; i < IXXAT_PCI_MAX_CHAN; i++) {
		ndev = intf->ndev[i];
		if (!ndev)
			continue;

		unregister_ifi_canfd_dev(ndev);
		free_ifi_canfd_dev(ndev);
	}

	ixxat_pci_free(intf);

	pci_set_drvdata(pdev, NULL);
	pci_disable_device(pdev);
}

static int ixxat_pci_probe(struct pci_dev *pdev,
			   const struct pci_device_id *id)
{
	struct ixxat_pci_interface *intf;
	struct ixxat_intf_caps intf_caps;
	int i;
	int err = pci_enable_device(pdev);

	if (err)
		return err;

	pci_set_master(pdev);

	intf = devm_kzalloc(&pdev->dev, sizeof(*intf), GFP_KERNEL);
	if (!intf)
		return -ENOMEM;

	pci_set_drvdata(pdev, intf);

	intf->pdev = pdev;
	intf->ctrl_idx = 0;

	err = ixxat_pci_register_dev(pdev, intf);
	if (err)
		goto lbl_set_intf;

	/* enable interface's pci interrupts  */
	err = ixxat_pci_int_ena_req(intf, 1);
	if (err)
		goto lbl_free_complete;

	err = ixxat_pci_get_intf_caps(pdev, intf, &intf_caps);
	if (err)
		goto lbl_free_complete;

	for (i = 0; i < intf_caps.bus_ctrl_count; i++) {
		if (IXXAT_PCI_BUS_TYPE(intf_caps.bus_ctrl_types[i])
			== IXXAT_PCI_BUS_CAN) {
			intf->ctrl_cnt++;
			err = ixxat_pci_create_dev(intf, pdev, i);
			if (err) {
				dev_err(&intf->pdev->dev,
					"Error %d: Device failed %d\n", err, i);
				ixxat_pci_remove(pdev);
				goto lbl_free_complete;
			}
		}

	}

	spin_lock_init(&intf->dev_lock);

	return err;

lbl_free_complete:
	ixxat_pci_free(intf);

lbl_set_intf:
	pci_disable_device(pdev);
	kfree(intf);

	return err;
}

static struct pci_driver ixxat_pci_driver = {
	.name = KBUILD_MODNAME, // IXXAT_PCI_DEV_NAME,
	.remove = ixxat_pci_remove,
	.probe = ixxat_pci_probe,
	.id_table = ixxat_pci_table,
};
module_pci_driver(ixxat_pci_driver);


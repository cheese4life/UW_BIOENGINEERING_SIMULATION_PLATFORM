SocketCAN drivers for IXXAT CAN interfaces
===============================================
2023-03-15
Changed with Kernel 6.1:
netif_napi_add(..) loose the parameter "int weight"
and call then internal the function netif_napi_add_weight(..)
with the parameter NAPI_POLL_WEIGHT

netif_napi_add_weight(..) available since Kernel 5.19

changed files:
- ixxat_pci_passive_canfd.c
- ixxat_pci_passive_can.c
- ixxat_pci_core.c
- ifi_canfd_platform.c
netif_napi_add -> netif_napi_add_weight

-----------------------------------------------
2023-03-14
Some functions was replaced with Kernel 5.18.0

Add a new header file common\ixxat_functions_pci.h.
It's only included in ixxat_pci_active project.

Copied the inline header functions from pci-dma-compat.h
pci_alloc_consistent -> dma_alloc_coherent
pci_free_consistent -> dma_free_coherent

-----------------------------------------------
2023-02-20
Add for the USB SocketCAN driver a flag to use
Low-Speed (fault tolerant) CAN.
There is in SocketCAN no switch to select this
at initialization.

Switch to Low-Speed CAN:

make clean / sudo make uninstall

File: ixxat_usb_core.h

Set the define to 1 and rebuild and install
the driver again:
Change: #define USE_LOWSPEED_CAN 1

-----------------------------------------------
2023-01-11
Modifications to make it able to compile on
newer Linux Kernel versions.
Supported Kernel Versions: 4.x - 6.0
Add some empty defines for functions from "led.h"
from the Kernel sources. This functions was
removed with Kernel version 5.19.


================================================
HMS Technology Center Ravensburg GmbH
www.ixxat.de
www.hms-networks.de